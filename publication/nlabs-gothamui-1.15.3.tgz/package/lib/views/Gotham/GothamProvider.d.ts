import i18n from 'i18next';
import type { FluxFramework, FluxMiddlewareType, FluxOptions } from '@nlabs/arkhamjs';
import type { FC, ReactNode } from 'react';
import type { GothamRouteData } from '../../types/gotham.js';
import type { AwsRum } from '../../utils/awsRum.js';
export interface GothamProviderProps {
    readonly children?: ReactNode;
    readonly config: GothamConfiguration;
    readonly session?: Record<string, unknown>;
}
export type GothamPosition = 't' | 'tc' | 'tl' | 'tr' | 'b' | 'bc' | 'br' | 'bl';
export type GothamStatus = 'default' | 'error' | 'info' | 'success' | 'warning' | number;
export type ThemeDisplayMode = 'auto' | 'dark' | 'light';
export interface GothamConfiguration {
    readonly analytics?: {
        readonly interactions?: boolean;
    };
    readonly app?: {
        readonly logo?: string;
        readonly name?: string;
        readonly title?: string;
        readonly titleBarSeparator?: string;
    };
    readonly authRoute?: string;
    readonly awsRum?: AwsRum;
    /** Browser route prefix; absolute Link and navigation targets remain inside this microsite. */
    readonly basename?: string;
    readonly baseUrl?: string;
    readonly config?: FluxOptions;
    readonly displayMode?: ThemeDisplayMode;
    readonly flux?: FluxFramework;
    readonly isAuth?: () => boolean;
    readonly middleware?: FluxMiddlewareType[];
    readonly onInit?: () => void;
    readonly routes?: GothamRouteData[];
    readonly storageType?: 'local' | 'session' | false;
    readonly stores?: unknown[];
    readonly theme?: Record<string, unknown>;
    readonly translations?: Record<string, unknown>;
    readonly i18n?: typeof i18n;
}
export declare const defaultGothamConfig: GothamConfiguration;
export declare const init: (config: GothamConfiguration) => () => void;
export declare const signOut: (flux: FluxFramework) => () => Promise<void>;
export declare const GothamProvider: FC<GothamProviderProps>;
