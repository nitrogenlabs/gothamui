import type { DocumentHeadOptions, PreparedHeadSnapshot } from './types.js';
export interface HeadLease {
    release: () => void;
    update: (snapshot: PreparedHeadSnapshot, options: DocumentHeadOptions) => void;
}
export declare const acquireDocumentHead: (doc: Document, owner: string, snapshot: PreparedHeadSnapshot, options: DocumentHeadOptions) => HeadLease;
