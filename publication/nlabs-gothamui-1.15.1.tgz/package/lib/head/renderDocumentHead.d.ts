import type { DocumentHeadMetadata } from './types.js';
export declare const renderDocumentHead: ({ metadata, owner }: {
    readonly metadata: DocumentHeadMetadata;
    readonly owner: string;
}) => string;
