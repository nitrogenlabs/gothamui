import type { DocumentHeadMetadata, PreparedHeadSnapshot } from './types.js';
export declare const prepareHeadMetadata: (owner: string, metadata: DocumentHeadMetadata) => PreparedHeadSnapshot;
