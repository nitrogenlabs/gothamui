/** Owns bounded sequential lookahead; disposal releases samples and cancels their iterator. */
export declare const createPreviewFrameQueue: <T extends {
    duration: number;
    timestamp: number;
}>(iterator: AsyncIterator<T>, options: {
    capacity: number;
    release?: (sample: T) => void;
}) => {
    at: (time: number) => T | undefined;
    destroy: () => void;
    readonly ended: boolean;
    fill: () => Promise<void>;
    readonly size: number;
};
