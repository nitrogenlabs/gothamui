export type TransitionFamily = 'cut' | 'dissolve' | 'dip' | 'wipe' | 'slide' | 'push' | 'zoom' | 'blur' | 'iris' | 'pixel';
export type TransitionDirection = 'left' | 'right' | 'up' | 'down' | 'in' | 'out';
interface TransitionDefinition {
    color?: 'black' | 'white';
    direction?: TransitionDirection;
    family: TransitionFamily;
    label: string;
    order: number;
    /** Conservative provisional export seconds per overlap second at 720p. */
    renderWeight: number;
}
/** Transition styles supported by the timeline compositor. */
export declare const TRANSITIONS: {
    readonly black: {
        readonly color: 'black';
        readonly family: 'dip';
        readonly label: 'Dip to black';
        readonly order: 2;
        readonly renderWeight: 3;
    };
    readonly blur: {
        readonly family: 'blur';
        readonly label: 'Blur dissolve';
        readonly order: 18;
        readonly renderWeight: 160;
    };
    readonly crossfade: {
        readonly family: 'dissolve';
        readonly label: 'Cross dissolve';
        readonly order: 1;
        readonly renderWeight: 2;
    };
    readonly cut: {
        readonly family: 'cut';
        readonly label: 'Cut';
        readonly order: 0;
        readonly renderWeight: 0;
    };
    readonly 'iris-close': {
        readonly direction: 'in';
        readonly family: 'iris';
        readonly label: 'Iris close';
        readonly order: 20;
        readonly renderWeight: 8;
    };
    readonly 'iris-open': {
        readonly direction: 'out';
        readonly family: 'iris';
        readonly label: 'Iris open';
        readonly order: 19;
        readonly renderWeight: 8;
    };
    readonly 'pixel-dissolve': {
        readonly family: 'pixel';
        readonly label: 'Pixel dissolve';
        readonly order: 21;
        readonly renderWeight: 12;
    };
    readonly 'push-down': {
        readonly direction: 'down';
        readonly family: 'push';
        readonly label: 'Push down';
        readonly order: 15;
        readonly renderWeight: 12;
    };
    readonly 'push-left': {
        readonly direction: 'left';
        readonly family: 'push';
        readonly label: 'Push left';
        readonly order: 12;
        readonly renderWeight: 12;
    };
    readonly 'push-right': {
        readonly direction: 'right';
        readonly family: 'push';
        readonly label: 'Push right';
        readonly order: 13;
        readonly renderWeight: 12;
    };
    readonly 'push-up': {
        readonly direction: 'up';
        readonly family: 'push';
        readonly label: 'Push up';
        readonly order: 14;
        readonly renderWeight: 12;
    };
    readonly 'slide-down': {
        readonly direction: 'down';
        readonly family: 'slide';
        readonly label: 'Slide down';
        readonly order: 11;
        readonly renderWeight: 8;
    };
    readonly 'slide-left': {
        readonly direction: 'left';
        readonly family: 'slide';
        readonly label: 'Slide left';
        readonly order: 8;
        readonly renderWeight: 8;
    };
    readonly 'slide-right': {
        readonly direction: 'right';
        readonly family: 'slide';
        readonly label: 'Slide right';
        readonly order: 9;
        readonly renderWeight: 8;
    };
    readonly 'slide-up': {
        readonly direction: 'up';
        readonly family: 'slide';
        readonly label: 'Slide up';
        readonly order: 10;
        readonly renderWeight: 8;
    };
    readonly white: {
        readonly color: 'white';
        readonly family: 'dip';
        readonly label: 'Dip to white';
        readonly order: 3;
        readonly renderWeight: 3;
    };
    readonly 'wipe-down': {
        readonly direction: 'down';
        readonly family: 'wipe';
        readonly label: 'Wipe down';
        readonly order: 7;
        readonly renderWeight: 4;
    };
    readonly 'wipe-left': {
        readonly direction: 'left';
        readonly family: 'wipe';
        readonly label: 'Wipe left';
        readonly order: 4;
        readonly renderWeight: 4;
    };
    readonly 'wipe-right': {
        readonly direction: 'right';
        readonly family: 'wipe';
        readonly label: 'Wipe right';
        readonly order: 5;
        readonly renderWeight: 4;
    };
    readonly 'wipe-up': {
        readonly direction: 'up';
        readonly family: 'wipe';
        readonly label: 'Wipe up';
        readonly order: 6;
        readonly renderWeight: 4;
    };
    readonly 'zoom-in': {
        readonly direction: 'in';
        readonly family: 'zoom';
        readonly label: 'Zoom in';
        readonly order: 16;
        readonly renderWeight: 20;
    };
    readonly 'zoom-out': {
        readonly direction: 'out';
        readonly family: 'zoom';
        readonly label: 'Zoom out';
        readonly order: 17;
        readonly renderWeight: 20;
    };
};
export type VideoTransition = keyof typeof TRANSITIONS;
export type TimelineTransition = VideoTransition | 'dissolve' | 'fade' | 'match';
export declare const VIDEO_TRANSITIONS: ("black" | "blur" | "crossfade" | "cut" | "iris-close" | "iris-open" | "pixel-dissolve" | "push-down" | "push-left" | "push-right" | "push-up" | "slide-down" | "slide-left" | "slide-right" | "slide-up" | "white" | "wipe-down" | "wipe-left" | "wipe-right" | "wipe-up" | "zoom-in" | "zoom-out")[];
export declare const isVideoTransition: (value: unknown) => value is VideoTransition;
export declare const isTimelineTransition: (value: unknown) => value is TimelineTransition;
export declare const normalizeTransition: (value: string) => VideoTransition;
export declare const transitionDefinition: (value: string) => TransitionDefinition;
export declare const TRANSITION_STYLE: {
    readonly blurRadius: 0.03;
    readonly blurSteps: 4;
    readonly pixelColumns: 32;
    readonly pixelRows: 18;
    readonly zoom: 0.4;
};
export declare const transitionPixelRank: (column: number, row: number) => number;
export {};
