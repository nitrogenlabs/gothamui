export interface PreviewScene {
    overlay?: boolean;
    text?: string;
    audio: {
        assetId: string;
        end: number;
        id: string;
        offset: number;
        start: number;
        url: string;
    }[];
    end: number;
    id: string;
    sourceStart: number;
    start: number;
    transition?: {
        duration: number;
        type: string;
    };
    visual?: {
        assetId: string;
        kind: 'video' | 'image';
        url: string;
    };
}
export declare const previewSourceTime: (scene: PreviewScene, position: number) => number;
export declare const previewLayers: (scenes: PreviewScene[], position: number) => {
    opacity: number;
    scene: PreviewScene;
}[];
export declare const previewAudioGain: (scenes: PreviewScene[], ids: string[], time: number) => number;
export declare const previewAudioReady: (audio: {
    availableUntil: number;
    end: number;
    ended: boolean;
    start: number;
}, time: number) => boolean;
