import type { PreviewScene } from './canvasPreviewTimeline.js';
export type { PreviewScene } from './canvasPreviewTimeline.js';
export interface CanvasPreviewOptions {
    mediaRequestInit?: (url: string) => RequestInit;
    canvas: HTMLCanvasElement;
    onEnded: () => void;
    onMetadata: (assetId: string, duration: number, width?: number, height?: number) => void;
    onPosition: (seconds: number) => void;
    onState: (state: {
        buffering: boolean;
        error?: string;
        ready: boolean;
    }) => void;
    resolveMediaUrl?: (url: string) => string;
    scenes: PreviewScene[];
}
/** A single decoded-frame compositor. No HTML media element owns playback or switches sources at a cut. */
export declare const createCanvasPreview: ({ canvas, mediaRequestInit, onEnded, onMetadata, onPosition, onState, resolveMediaUrl, scenes }: CanvasPreviewOptions) => {
    destroy: () => void;
    pause: () => void;
    play: () => Promise<void>;
    prepare: (time: number) => Promise<void>;
    seek: (time: number) => Promise<void>;
    setMuted: (value: boolean) => void;
    setRatio: (ratio: number) => void;
};
