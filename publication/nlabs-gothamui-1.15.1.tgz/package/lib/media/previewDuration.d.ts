import type { Input } from 'mediabunny';
/** Avoid scanning remote packets when the container already supplies a duration. */
export declare const previewDuration: (input: Pick<Input, 'computeDuration' | 'getDurationFromMetadata'>) => Promise<number>;
