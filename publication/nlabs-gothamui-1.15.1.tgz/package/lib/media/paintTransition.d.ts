/** Composite decoded frames without reading pixels back to the CPU or allocating canvases per tick. */
export declare const paintTransition: (context: CanvasRenderingContext2D, width: number, height: number, type: string, progress: number, outgoing: () => void, incoming: () => void) => void;
