import type { EditorProps } from '@monaco-editor/react';
export type CodeEditorProps = EditorProps;
/**
 * Shared code editor backed by Monaco.
 *
 * Import from `@nlabs/gothamui/editor` so Monaco remains outside the normal
 * GothamUI component entry point for applications that do not use an editor.
 */
declare const CodeEditorComponent: (props: CodeEditorProps) => import("react").JSX.Element;
export type { BeforeMount, EditorProps, Monaco, OnChange, OnMount, OnValidate } from '@monaco-editor/react';
export declare const CodeEditor: import("react").MemoExoticComponent<typeof CodeEditorComponent>;
