/**
 * Copyright (c) 2018-Present, Nitrogen Labs, Inc.
 * Copyrights licensed under the MIT License. See the accompanying LICENSE file for terms.
 */
export type GothamColor = 'primary' | 'secondary' | 'tertiary' | 'link' | 'neutral' | 'white' | 'black' | 'error' | 'warning' | 'success' | 'info' | 'transparent';
export declare const colorLuminance: (hexValue: string, luminance?: number) => string;
export declare const gothamColors: readonly ['primary', 'secondary', 'tertiary', 'link', 'neutral', 'black', 'white', 'error', 'warning', 'success', 'info'];
export interface StyleClassOptions {
    readonly hasError?: boolean;
    readonly hasFocus?: boolean;
    readonly hasHover?: boolean;
}
export declare const getTextClasses: (color: GothamColor, options?: StyleClassOptions) => string;
export declare const getPlaceholderClasses: (color: GothamColor, options?: StyleClassOptions) => string;
export declare const getErrorClasses: (errorColor: GothamColor) => "text-error dark:text-error-dark" | "text-info dark:text-info-dark" | "text-success dark:text-success-dark" | "text-warning dark:text-warning-dark";
export declare const getBorderClasses: (color: GothamColor, options?: StyleClassOptions) => string;
export declare const getOutlineClasses: (color: GothamColor, options?: StyleClassOptions) => string;
export declare const getCheckedClasses: (color: GothamColor) => string;
export declare const getBackgroundClasses: (color: GothamColor, options?: StyleClassOptions) => string;
export declare const getBackgroundViewClasses: (color: GothamColor, options?: StyleClassOptions) => string;
