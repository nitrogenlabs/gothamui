export type AwsRumEventType = 'change' | 'click' | 'edit' | 'page_view' | 'submit' | (string & {});
export interface AwsRumTrackEvent {
    readonly name: string;
    readonly path?: string;
    readonly properties?: Record<string, boolean | number | string>;
    readonly type: AwsRumEventType;
}
export interface AwsRum {
    readonly track: (event: AwsRumTrackEvent) => void;
}
export interface AwsRumDebugOptions {
    readonly enabled?: boolean;
    readonly logger?: (message: string, event: AwsRumTrackEvent) => void;
    readonly target?: AwsRum;
}
export declare const GOTHAM_ANALYTICS_EVENT = "nlabs:gotham:analytics";
/**
 * Emits analytics onto Gotham's browser channel. Metropolis subscribes to this
 * channel automatically, which keeps the two packages independently usable.
 */
export declare const createAwsRumBrowserClient: () => AwsRum;
export declare const createAwsRumDebugClient: ({ enabled, logger, target }?: AwsRumDebugOptions) => AwsRum;
export declare const useAwsRum: () => AwsRum | undefined;
