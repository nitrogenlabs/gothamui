import type { AwsRum } from './awsRum.js';
export type ViewPerformanceOutcome = 'cancelled' | 'failure' | 'success' | 'timeout';
export type ViewPerformanceStatus = 'failure' | 'pending' | 'success';
export interface ViewPerformanceMeasurement {
    readonly durationMs: number;
    readonly outcome: ViewPerformanceOutcome;
    readonly route?: string;
    readonly title?: string;
    readonly viewId: string;
}
export interface StartViewOptions {
    readonly now?: () => number;
    readonly onComplete: (measurement: ViewPerformanceMeasurement) => void;
    readonly route?: string;
    readonly timeoutMs?: number;
    readonly title?: string;
    readonly viewId: string;
}
export interface ViewPerformanceHandle {
    readonly cancel: () => void;
    readonly fail: () => void;
    readonly succeed: () => void;
    readonly timeout: () => void;
}
export interface UseViewPerformanceOptions {
    readonly route?: string;
    readonly status: ViewPerformanceStatus;
    readonly timeoutMs?: number;
    readonly title?: string;
    readonly viewId: string;
}
export declare const startView: ({ now, onComplete, route, timeoutMs, title, viewId }: StartViewOptions) => ViewPerformanceHandle;
export declare const reportViewPerformance: (awsRum: AwsRum | undefined, measurement: ViewPerformanceMeasurement) => void;
export declare const useViewPerformance: ({ route, status, timeoutMs, title, viewId }: UseViewPerformanceOptions) => void;
