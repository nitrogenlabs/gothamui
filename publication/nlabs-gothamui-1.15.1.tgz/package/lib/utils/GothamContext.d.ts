/**
 * Copyright (c) 2018-Present, Nitrogen Labs, Inc.
 * Copyrights licensed under the MIT License. See the accompanying LICENSE file for terms.
 */
import { type FluxFramework } from '@nlabs/arkhamjs';
import type { AwsRum } from './awsRum.js';
export interface GothamContextProps {
    readonly awsRum?: AwsRum;
    readonly children?: React.ReactNode;
    readonly Flux: FluxFramework;
    readonly isAuth?: () => boolean;
    readonly session?: Record<string, unknown>;
}
export declare const GothamContext: import("react").Context<GothamContextProps>;
