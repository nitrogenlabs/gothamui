/**
 * Copyright (c) 2018-Present, Nitrogen Labs, Inc.
 * Copyrights licensed under the MIT License. See the accompanying LICENSE file for terms.
 */
/**
 * Create a Timer
 * @param {Number} delay
 * @param {Function} callback
 * @constructor
 */
export declare class GothamTimer {
    timerId: unknown;
    start: number;
    remaining: number;
    delay: number;
    callback: unknown;
    constructor(delay: number, callback: unknown);
    pause(): void;
    resume(): void;
    getTimeRemaining(): number;
}
