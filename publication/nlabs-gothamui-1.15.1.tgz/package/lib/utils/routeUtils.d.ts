import type { RouteObject } from 'react-router';
import type { GothamRouteAnalyticsSource } from '../types/gotham.js';
export type CustomRouteProps = RouteObject & {
    readonly analytics?: GothamRouteAnalyticsSource;
    readonly authenticate?: boolean;
    readonly props?: Record<string, unknown>;
    readonly routes?: CustomRouteProps[];
};
export declare const parseRoutes: (routes?: CustomRouteProps[], parentPath?: string) => RouteObject[];
