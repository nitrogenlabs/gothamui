export declare const i18n: (key: string | string[], defaultValue?: string, options?: Record<string, unknown>, locale?: string) => string;
