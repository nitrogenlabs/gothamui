import type { RefObject } from 'react';
export declare const useFluidCollapse: (panel: RefObject<HTMLDivElement | null>, content: RefObject<HTMLDivElement | null>, open: boolean) => void;
