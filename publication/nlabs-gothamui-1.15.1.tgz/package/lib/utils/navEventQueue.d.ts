type Handler = (data: any) => void;
export declare const enqueue: (type: string, data: any) => void;
export declare const registerHandler: (type: string, handler: Handler) => void;
export declare const clear: () => void;
export declare const registerFlux: (flux: any) => (() => void);
export {};
