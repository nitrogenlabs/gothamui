import type { NavigateFunction, NavigateOptions } from 'react-router';
export interface NavigationEvent {
    readonly params?: NavigateOptions;
    readonly path?: string;
}
export declare const navBack: (navigate: NavigateFunction) => () => void;
export declare const navForward: (navigate: NavigateFunction) => () => void;
export declare const navGoto: (navigate: NavigateFunction) => ({ params, path }: NavigationEvent) => void;
export declare const navReplace: (navigate: NavigateFunction) => ({ params, path }: NavigationEvent) => void;
