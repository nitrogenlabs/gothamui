export declare const gothamDecorator: (Story: any) => import("react").JSX.Element;
