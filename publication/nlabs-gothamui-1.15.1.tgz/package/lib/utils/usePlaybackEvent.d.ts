/** Stable callbacks for media subscriptions, compatible with all React 19 releases. */
export declare const usePlaybackEvent: <Args extends unknown[], Result>(callback: (...args: Args) => Result) => (...args: Args) => Result;
