export declare const getTestElement: (name: string, index?: number) => HTMLElement;
export declare const renderWithProvider: any;
export declare const renderWithForm: any;
