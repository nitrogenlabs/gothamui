export declare const fetchJsonFromUrl: <T = unknown>(url: string) => Promise<T>;
export declare const parseTemplate: (markdown?: string, values?: Record<string, unknown>) => string;
