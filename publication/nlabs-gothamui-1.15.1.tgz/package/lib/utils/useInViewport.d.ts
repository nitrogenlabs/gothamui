/** Releases offscreen media, with a fallback for browsers without intersection observation. */
export declare const useInViewport: (element: HTMLElement | null) => boolean;
