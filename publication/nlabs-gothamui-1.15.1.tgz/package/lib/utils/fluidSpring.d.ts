export interface FluidSpringState {
    position: number;
    velocity: number;
}
/** Unit mass with spring force and fluid drag; small substeps remain stable after slow frames. */
export declare const advanceFluidSpring: (state: FluidSpringState, target: number, elapsed: number) => FluidSpringState;
