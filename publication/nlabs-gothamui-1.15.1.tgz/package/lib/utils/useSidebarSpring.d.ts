import type { RefObject } from 'react';
/** Preserve velocity across direction changes and honor live reduced-motion preferences. */
export declare const useSidebarSpring: (panel: RefObject<HTMLElement | null>, open: boolean) => void;
