import { Location, useNavigation } from 'react-router';
export interface AppRouter {
    readonly location: Location;
    readonly matches: unknown[];
    readonly navigation: ReturnType<typeof useNavigation>;
    readonly params: unknown;
}
export declare const useRoute: () => AppRouter;
export declare const parseNavUrl: (path: string, params: Record<string, unknown>) => string;
