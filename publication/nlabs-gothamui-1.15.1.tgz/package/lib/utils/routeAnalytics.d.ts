import type { GothamRouteAnalytics } from '../types/gotham.js';
export declare const resolveRouteAnalytics: (matches: readonly {
    readonly handle?: unknown;
}[], pathname: string) => GothamRouteAnalytics | undefined;
