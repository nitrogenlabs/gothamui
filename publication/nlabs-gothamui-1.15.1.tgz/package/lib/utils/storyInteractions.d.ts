type StoryContext = {
    readonly canvasElement: HTMLElement;
};
export declare const interactWithCanvas: ({ canvasElement }: StoryContext) => Promise<void>;
export declare const focusCanvas: ({ canvasElement }: StoryContext) => Promise<void>;
export {};
