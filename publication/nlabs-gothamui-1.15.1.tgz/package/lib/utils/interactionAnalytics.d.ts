/**
 * Copyright (c) 2026-Present, Nitrogen Labs, Inc.
 * Copyrights licensed under the MIT License. See the accompanying LICENSE file for terms.
 */
import type { AwsRum } from './awsRum.js';
/**
 * Tracks semantic interactions with one delegated listener per event type.
 * Values, visible text, URLs, and query strings are deliberately excluded.
 */
export declare const registerInteractionAnalytics: (awsRum: AwsRum, ownerDocument?: Document | undefined) => (() => void);
