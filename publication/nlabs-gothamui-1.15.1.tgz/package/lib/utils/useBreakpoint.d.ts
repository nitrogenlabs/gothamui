export declare const useBreakpoint: () => {
    at: (size: string) => boolean;
    down: (size: string) => boolean;
    up: (size: string) => boolean;
    value: () => string;
};
