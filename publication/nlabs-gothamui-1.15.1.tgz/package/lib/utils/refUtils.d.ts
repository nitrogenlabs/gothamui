import type { Ref } from 'react';
export declare const assignRef: <T>(ref: Ref<T> | undefined, value: T | null) => void;
