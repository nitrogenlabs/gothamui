export declare const formatPlaybackTime: (seconds: number) => string;
export declare const playbackRatioPresets: readonly [{
    readonly label: '9:16';
    readonly value: number;
}, {
    readonly label: '3:4';
    readonly value: number;
}, {
    readonly label: '1:1';
    readonly value: 1;
}, {
    readonly label: '4:3';
    readonly value: number;
}, {
    readonly label: '16:9';
    readonly value: number;
}, {
    readonly label: '21:9';
    readonly value: number;
}];
