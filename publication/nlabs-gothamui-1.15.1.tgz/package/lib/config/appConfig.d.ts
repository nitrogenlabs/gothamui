export declare class Config {
    static values: Record<string, unknown>;
    static set: (values: Record<string, unknown>) => Record<string, unknown>;
    static get(path: string | string[], defaultValue?: unknown): unknown;
}
