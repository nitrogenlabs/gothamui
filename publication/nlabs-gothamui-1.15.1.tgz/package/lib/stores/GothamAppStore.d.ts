interface AppState {
    isLoading?: boolean;
    loadingContent?: string;
    notify?: {
        actions?: any[];
        anchorOrigin?: {
            horizontal: string;
            vertical: string;
        };
        autoHideDuration?: number;
        isOpen?: boolean;
        key?: string | number;
        message?: string;
        severity?: string;
    };
    title?: string;
    config?: any;
}
export declare const gothamApp: {
    initialState: {
        isLoading: boolean;
        loadingContent: string;
        notify: {
            actions: never[];
            autoHideDuration: number;
            isOpen: boolean;
            message: string;
            severity: string;
        };
        title: string;
    };
    name: string;
    action: (type: string, data: any, state?: AppState) => AppState;
};
export {};
