import type { ReactNode } from 'react';
import type { AuthSignUpValues } from '../../form/authTypes.js';
import type { AuthViewProps } from '../AuthView/AuthView.js';
export type { AuthSignUpValues } from '../../form/authTypes.js';
export interface AuthSignUpViewProps extends Omit<AuthViewProps, 'cardDescription' | 'cardTitle' | 'children' | 'onSubmit'> {
    readonly cardDescription?: ReactNode;
    readonly cardTitle?: ReactNode;
    readonly error?: ReactNode;
    readonly onSubmit: (values: AuthSignUpValues) => void | Promise<void>;
    readonly resendVerificationHref?: string;
    readonly signInHref?: string;
    readonly submitClassName?: string;
    readonly termsHref?: string;
}
declare const AuthSignUpViewComponent: ({ cardClassName, cardDescription, cardHeaderClassName, cardTitle, error, onSubmit, resendVerificationHref, signInHref, submitClassName, termsHref, ...authViewProps }: AuthSignUpViewProps) => import("react").JSX.Element;
export declare const AuthSignUpView: import("react").MemoExoticComponent<typeof AuthSignUpViewComponent>;
