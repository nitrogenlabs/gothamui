import type { ElementType } from 'react';
export type MenuItems = {
    readonly current?: boolean;
    readonly href: string;
    readonly icon?: ElementType;
    readonly name: string;
};
export interface MenuViewProps {
    sideMenuItems: MenuItems[];
    userMenuItems: MenuItems[];
}
export declare const MenuView: import("react").NamedExoticComponent<MenuViewProps>;
export default MenuView;
