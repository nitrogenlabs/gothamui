export declare const NotFoundView: import("react").NamedExoticComponent<{}>;
export default NotFoundView;
