import type { HTMLAttributes, ReactNode } from 'react';
export interface AuthViewProps extends Omit<HTMLAttributes<HTMLElement>, 'title'> {
    readonly cardClassName?: string;
    readonly cardDescription: ReactNode;
    readonly cardHeaderClassName?: string;
    readonly cardTitle: ReactNode;
    readonly description: ReactNode;
    readonly descriptionClassName?: string;
    readonly eyebrow?: ReactNode;
    readonly eyebrowClassName?: string;
    readonly title: ReactNode;
    readonly titleClassName?: string;
}
declare const AuthViewComponent: ({ cardClassName, cardDescription, cardHeaderClassName, cardTitle, children, className, description, descriptionClassName, eyebrow, eyebrowClassName, title, titleClassName, ...props }: AuthViewProps) => import("react").JSX.Element;
export declare const AuthView: import("react").MemoExoticComponent<typeof AuthViewComponent>;
export {};
