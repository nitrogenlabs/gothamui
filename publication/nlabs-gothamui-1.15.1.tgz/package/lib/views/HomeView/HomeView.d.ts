/**
 * Copyright (c) 2018-Present, Nitrogen Labs, Inc.
 * Copyrights licensed under the MIT License. See the accompanying LICENSE file for terms.
 */
import React from 'react';
export interface HomeViewProps {
    children?: React.ReactNode;
    title?: string;
}
export declare const HomeView: React.NamedExoticComponent<HomeViewProps>;
