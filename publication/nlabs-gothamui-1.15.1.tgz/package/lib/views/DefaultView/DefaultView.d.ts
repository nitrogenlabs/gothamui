export interface DefaultViewProps {
    children?: React.ReactNode;
    title?: string;
}
export declare const DefaultView: import("react").NamedExoticComponent<DefaultViewProps>;
