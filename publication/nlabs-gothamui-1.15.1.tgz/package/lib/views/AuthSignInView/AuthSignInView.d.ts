import type { ReactNode } from 'react';
import type { AuthSignInValues } from '../../form/authTypes.js';
import type { AuthViewProps } from '../AuthView/AuthView.js';
export type { AuthSignInValues } from '../../form/authTypes.js';
export interface AuthSignInViewProps extends Omit<AuthViewProps, 'cardDescription' | 'cardTitle' | 'children' | 'onSubmit'> {
    readonly cardDescription?: ReactNode;
    readonly cardTitle?: ReactNode;
    readonly defaultEmail?: string;
    readonly error?: ReactNode;
    readonly forgotPasswordHref?: string;
    readonly onSubmit: (values: AuthSignInValues) => void | Promise<void>;
    readonly signUpHref?: string;
    readonly submitClassName?: string;
}
declare const AuthSignInViewComponent: ({ cardDescription, cardTitle, defaultEmail, error, forgotPasswordHref, onSubmit, signUpHref, submitClassName, ...authViewProps }: AuthSignInViewProps) => import("react").JSX.Element;
export declare const AuthSignInView: import("react").MemoExoticComponent<typeof AuthSignInViewComponent>;
