export interface LoaderContent {
    content?: string;
    isLoading: boolean;
}
export declare const toggleLoader: (setLoading: any, setLoaderContent: any) => ({ content, isLoading }: LoaderContent) => void;
declare const LoaderViewComponent: () => import("react").JSX.Element | null;
export declare const LoaderView: import("react").MemoExoticComponent<typeof LoaderViewComponent>;
export {};
