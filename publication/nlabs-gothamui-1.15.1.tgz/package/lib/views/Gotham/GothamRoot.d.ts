import type { FC } from 'react';
export { navBack, navForward, navGoto, navReplace } from '../../utils/navigationHandlers.js';
export declare const GothamRoot: FC;
