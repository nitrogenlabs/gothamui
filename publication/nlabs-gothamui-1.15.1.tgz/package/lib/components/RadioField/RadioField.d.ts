import { type GothamColor } from '../../utils/colorUtils.js';
export interface RadioFieldItem {
    readonly description?: string;
    readonly id?: string;
    readonly label: string;
    readonly value: string;
}
export interface RadioFieldProps {
    readonly color?: GothamColor;
    readonly defaultValue?: string;
    readonly label?: string;
    readonly name: string;
    readonly optionClass?: string;
    readonly options: RadioFieldItem[];
}
export declare const RadioField: import("react").NamedExoticComponent<RadioFieldProps>;
