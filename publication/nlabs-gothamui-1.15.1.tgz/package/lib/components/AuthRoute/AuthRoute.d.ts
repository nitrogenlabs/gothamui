export declare const AuthRoute: ({ children }: {
    children: any;
}) => any;
