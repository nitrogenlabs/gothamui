import type { FC } from 'react';
import type { GothamColor } from '../../utils/colorUtils.js';
export interface ErrorMessageProps {
    readonly color?: GothamColor;
    readonly message?: string;
}
export declare const ErrorMessage: FC<ErrorMessageProps>;
