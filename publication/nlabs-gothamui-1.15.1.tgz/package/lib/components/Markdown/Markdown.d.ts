import React from 'react';
export interface MarkdownProps {
    className?: string;
    content?: string;
    url?: string;
    values?: Record<string, unknown>;
}
export declare const Markdown: React.NamedExoticComponent<MarkdownProps>;
