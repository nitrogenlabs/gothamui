export type PaginationVariant = 'centered' | 'simple';
export type PaginationResultLabel = 'items' | 'results';
export interface PaginationProps {
    readonly className?: string;
    readonly currentPage: number;
    readonly pageSize?: number;
    readonly nextLabel?: string;
    readonly onPageChange?: (page: number) => void;
    readonly pageLabel?: (page: number) => string;
    readonly previousLabel?: string;
    readonly resultLabel?: PaginationResultLabel;
    readonly showLabels?: boolean;
    readonly siblingCount?: number;
    readonly totalItems?: number;
    readonly totalPages: number;
    readonly variant?: PaginationVariant;
}
export declare const Pagination: ({ className, currentPage, pageSize, nextLabel, onPageChange, pageLabel, previousLabel, resultLabel, showLabels, siblingCount, totalItems, totalPages, variant }: PaginationProps) => import("react").JSX.Element | null;
