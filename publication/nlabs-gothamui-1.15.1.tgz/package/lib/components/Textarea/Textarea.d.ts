import type { Ref, TextareaHTMLAttributes } from 'react';
export interface TextareaProps extends TextareaHTMLAttributes<HTMLTextAreaElement> {
    readonly ref?: Ref<HTMLTextAreaElement>;
}
export declare const Textarea: ({ className, ref, ...props }: TextareaProps) => import("react").JSX.Element;
