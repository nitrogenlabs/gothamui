import type { ComponentType, HTMLAttributes, ReactNode, SVGProps } from 'react';
export type NotFoundVariant = 'simple' | 'popular' | 'split' | 'background';
export interface NotFoundLink {
    readonly description?: string;
    readonly href: string;
    readonly icon?: ComponentType<SVGProps<SVGSVGElement>>;
    readonly label: string;
}
export interface NotFoundSocialLink {
    readonly href: string;
    readonly icon: ComponentType<SVGProps<SVGSVGElement>>;
    readonly label: string;
}
export interface NotFoundProps extends Omit<HTMLAttributes<HTMLDivElement>, 'title'> {
    readonly backgroundImageAlt?: string;
    readonly backgroundImageSrc?: string;
    readonly copyright?: ReactNode;
    readonly description?: ReactNode;
    readonly footerLinks?: readonly NotFoundLink[];
    readonly homeHref?: string;
    readonly homeLabel?: string;
    readonly imageAlt?: string;
    readonly imageSrc?: string;
    readonly links?: readonly NotFoundLink[];
    readonly logo?: ReactNode;
    readonly socialLinks?: readonly NotFoundSocialLink[];
    readonly statusCode?: ReactNode;
    readonly supportHref?: string;
    readonly supportLabel?: string;
    readonly title?: ReactNode;
    readonly variant?: NotFoundVariant;
}
export declare const NotFound: ({ backgroundImageAlt, backgroundImageSrc, className, copyright, description, footerLinks, homeHref, homeLabel, imageAlt, imageSrc, links, logo, socialLinks, statusCode, supportHref, supportLabel, title, variant, ...props }: NotFoundProps) => import("react").JSX.Element;
export default NotFound;
