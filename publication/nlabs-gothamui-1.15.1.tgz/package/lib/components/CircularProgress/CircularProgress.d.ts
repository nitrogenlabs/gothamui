import type { ReactElement } from 'react';
export interface CircularProgressProps {
    readonly className?: string;
    readonly label?: string;
    readonly size?: number;
    readonly value: number;
}
/** Eclipse: a determinate, gradient ring with a soft glow and no continuous motion. */
export declare const CircularProgress: ({ className, label, size, value }: CircularProgressProps) => ReactElement;
