import type { ElementType, ReactNode } from 'react';
type AsChildProps = {
    readonly as?: ElementType;
    readonly asChild?: boolean;
    readonly children?: ReactNode;
    readonly className?: string;
};
export declare const renderWithAsChild: <Props extends AsChildProps>({ as: Comp, asChild, children, className, ...props }: Props, dataAttributes?: Record<string, string | undefined>) => import("react").JSX.Element | null;
export {};
