import type { ElementType, HTMLAttributes, ReactNode } from 'react';
export type BadgeVariant = 'default' | 'secondary' | 'destructive' | 'outline' | 'ghost' | 'link';
export interface BadgeProps extends HTMLAttributes<HTMLElement> {
    readonly as?: ElementType;
    readonly asChild?: boolean;
    readonly children?: ReactNode;
    readonly variant?: BadgeVariant;
}
export declare const Badge: ({ as, asChild, children, className, variant, ...props }: BadgeProps) => import("react").JSX.Element | null;
