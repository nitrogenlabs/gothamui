import type { HTMLAttributes, ReactNode } from 'react';
export interface IncentiveItem {
    readonly description: ReactNode;
    readonly icon?: ReactNode;
    readonly id?: string;
    readonly imageAlt?: string;
    readonly imageSrc?: string;
    readonly title: ReactNode;
}
export interface IncentiveGridProps extends HTMLAttributes<HTMLDivElement> {
    readonly incentives: IncentiveItem[];
}
declare const IncentiveGridComponent: ({ className, incentives, ...props }: IncentiveGridProps) => import("react").JSX.Element;
export declare const IncentiveGrid: import("react").MemoExoticComponent<typeof IncentiveGridComponent>;
export {};
