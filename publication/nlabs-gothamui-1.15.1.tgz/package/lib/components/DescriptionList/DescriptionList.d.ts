import type { ComponentPropsWithoutRef } from 'react';
export declare const DescriptionList: ({ className, ...props }: ComponentPropsWithoutRef<'dl'>) => import("react").JSX.Element;
export declare const DescriptionTerm: ({ className, ...props }: ComponentPropsWithoutRef<'dt'>) => import("react").JSX.Element;
export declare const DescriptionDetails: ({ className, ...props }: ComponentPropsWithoutRef<'dd'>) => import("react").JSX.Element;
