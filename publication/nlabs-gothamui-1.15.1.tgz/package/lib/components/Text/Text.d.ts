import type { AnchorHTMLAttributes, ComponentPropsWithoutRef } from 'react';
export declare const Text: ({ className, ...props }: ComponentPropsWithoutRef<'p'>) => import("react").JSX.Element;
export declare const TextLink: ({ className, ...props }: AnchorHTMLAttributes<HTMLAnchorElement>) => import("react").JSX.Element;
export declare const Strong: ({ className, ...props }: ComponentPropsWithoutRef<'strong'>) => import("react").JSX.Element;
export declare const Code: ({ className, ...props }: ComponentPropsWithoutRef<'code'>) => import("react").JSX.Element;
