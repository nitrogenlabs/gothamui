import type { ReactElement, ReactNode, Ref } from 'react';
export declare const playerButton = "flex size-9 shrink-0 cursor-pointer items-center justify-center rounded-lg text-white/85 transition hover:bg-white/15 hover:text-white focus-visible:outline-2 focus-visible:outline-violet-300 disabled:cursor-not-allowed disabled:opacity-35";
export declare const playerGlass = "flex h-12 shrink-0 items-center gap-0.5 rounded-xl bg-white/[0.14] shadow-lg backdrop-blur-xl";
export interface PlaybackControlsProps {
    readonly children?: ReactNode;
    readonly compact?: boolean;
    readonly duration: number;
    readonly label?: string;
    readonly markers?: number[];
    readonly muted: boolean;
    readonly onFullscreen: () => void;
    readonly onMute: () => void;
    readonly onPause: () => void;
    readonly onSeek: (seconds: number) => void;
    readonly onToggle: () => void;
    readonly options?: ReactNode;
    readonly playDisabled?: boolean;
    readonly playing: boolean;
    readonly progressFill?: Ref<HTMLSpanElement>;
    readonly progressThumb?: Ref<HTMLSpanElement>;
    readonly scrubber?: Ref<HTMLInputElement>;
    readonly seekLabel: string;
    readonly step?: number;
    readonly time: ReactNode;
}
/** Presentation only: native media and the Flux timeline retain their own clocks and commands. */
export declare const PlaybackControls: ({ children, compact, duration, label, markers, muted, onFullscreen, onMute, onPause, onSeek, onToggle, options, playDisabled, playing, progressFill, progressThumb, scrubber, seekLabel, step, time }: PlaybackControlsProps) => ReactElement;
