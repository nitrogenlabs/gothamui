import type { AnchorHTMLAttributes, ElementType, ReactNode } from 'react';
export interface LinkProps extends AnchorHTMLAttributes<HTMLAnchorElement> {
    readonly as?: ElementType;
    readonly asChild?: boolean;
    readonly children?: ReactNode;
}
export declare const Link: ({ as, asChild, children, className, ...props }: LinkProps) => import("react").JSX.Element | null;
