import type { FC } from 'react';
export interface SvgProps {
    readonly className?: string;
    readonly color?: string;
    readonly height?: number;
    readonly name: string;
    readonly width?: number;
}
export declare const Svg: FC<SvgProps>;
