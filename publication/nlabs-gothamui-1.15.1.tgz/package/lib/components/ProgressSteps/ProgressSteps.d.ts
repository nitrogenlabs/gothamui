import type { HTMLAttributes } from 'react';
export type ProgressStepStatus = 'complete' | 'current' | 'upcoming';
export interface ProgressStepItem {
    readonly href?: string;
    readonly id?: string;
    readonly label: string;
    readonly status: ProgressStepStatus;
}
export interface ProgressStepsProps extends HTMLAttributes<HTMLElement> {
    readonly ariaLabel?: string;
    readonly steps: ProgressStepItem[];
}
export declare const ProgressSteps: ({ ariaLabel, className, steps, ...props }: ProgressStepsProps) => import("react").JSX.Element;
