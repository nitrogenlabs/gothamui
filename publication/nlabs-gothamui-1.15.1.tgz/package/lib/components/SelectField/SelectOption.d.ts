export type SelectFieldOption = {
    readonly icon?: string;
    readonly id?: number | string;
    readonly image?: string;
    readonly label: string;
    readonly value: string | number | boolean;
};
export type SelectOptionProps = {
    readonly option: SelectFieldOption;
};
declare const SelectOptionComponent: ({ option }: SelectOptionProps) => import("react").JSX.Element;
export declare const SelectOption: import("react").MemoExoticComponent<typeof SelectOptionComponent>;
export {};
