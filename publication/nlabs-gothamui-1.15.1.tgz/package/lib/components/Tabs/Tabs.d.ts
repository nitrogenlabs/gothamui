import type { HTMLAttributes } from 'react';
export interface TabItem {
    readonly current?: boolean;
    readonly disabled?: boolean;
    readonly href?: string;
    readonly id?: string;
    readonly label: string;
}
export interface TabsProps extends HTMLAttributes<HTMLDivElement> {
    readonly ariaLabel?: string;
    readonly items: TabItem[];
    readonly onTabChange?: (item: TabItem) => void;
    readonly variant?: 'underline' | 'pills';
}
declare const TabsComponent: ({ ariaLabel, className, items, onTabChange, variant, ...props }: TabsProps) => import("react").JSX.Element;
export declare const Tabs: import("react").MemoExoticComponent<typeof TabsComponent>;
export {};
