import 'yet-another-react-lightbox/styles.css';
import type { FC } from 'react';
type LightboxNavDirection = 'next' | 'prev';
export interface MediaLightboxProps {
    readonly close?: () => void;
    readonly enableVideo?: boolean;
    readonly hideNavigationWhenSingle?: boolean;
    readonly index?: number;
    readonly on?: Record<string, unknown>;
    readonly open?: boolean;
    readonly plugins?: unknown[];
    readonly render?: Record<string, unknown>;
    readonly slides?: unknown[];
    readonly toolbar?: Record<string, unknown>;
    readonly video?: Record<string, unknown>;
}
export declare const MediaLightboxCloseButton: () => import("react").JSX.Element;
export declare const MediaLightboxNavButton: FC<{
    readonly direction: LightboxNavDirection;
}>;
export declare const MediaLightbox: import("react").NamedExoticComponent<MediaLightboxProps>;
export {};
