import type { HTMLAttributes } from 'react';
export type ContainerSize = 'sm' | 'md' | 'lg' | 'xl' | 'full';
export interface ContainerProps extends HTMLAttributes<HTMLDivElement> {
    readonly bleed?: boolean;
    readonly size?: ContainerSize;
}
export declare const Container: ({ bleed, className, size, ...props }: ContainerProps) => import("react").JSX.Element;
