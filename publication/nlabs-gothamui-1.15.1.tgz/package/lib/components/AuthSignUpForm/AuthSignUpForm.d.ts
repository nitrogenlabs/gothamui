import type { AuthFieldOptions, AuthFormProps, AuthSignUpValues } from '../../form/authTypes.js';
import type { CheckboxProps } from '../Checkbox/Checkbox.js';
export type { AuthSignUpValues } from '../../form/authTypes.js';
export interface AuthSignUpFormProps extends AuthFormProps<AuthSignUpValues> {
    readonly fields?: Partial<Record<'confirmPassword' | 'email' | 'password', AuthFieldOptions>>;
    readonly showPasswordStrength?: boolean;
    readonly termsProps?: Partial<Pick<CheckboxProps, 'containerClass' | 'description' | 'label' | 'labelClass' | 'optionClass'>>;
}
declare const AuthSignUpFormComponent: ({ beforeSubmit, className, fields, fieldsClassName, name, onSubmit, optionsClassName, optionsContent, pendingLabel, schema, showPasswordStrength, showSubmitLoading, submitClassName, submitLabel, submitVariant, termsProps }: AuthSignUpFormProps) => import("react").JSX.Element;
export declare const AuthSignUpForm: import("react").MemoExoticComponent<typeof AuthSignUpFormComponent>;
