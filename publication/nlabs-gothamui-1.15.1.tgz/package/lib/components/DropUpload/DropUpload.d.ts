import type { HTMLAttributes, ReactNode, Ref } from 'react';
export type DropUploadRejectionReason = 'max-files' | 'max-size' | 'type';
export interface DropUploadItem {
    readonly file: File;
    readonly id: string;
    readonly previewUrl?: string;
}
export interface DropUploadRejection {
    readonly file: File;
    readonly reason: DropUploadRejectionReason;
}
export interface DropUploadProps extends Omit<HTMLAttributes<HTMLDivElement>, 'onChange' | 'onDrop'> {
    readonly accept?: string;
    readonly browseLabel?: string;
    readonly defaultFiles?: readonly File[];
    readonly disabled?: boolean;
    readonly files?: readonly File[];
    readonly helperText?: ReactNode;
    readonly imageOutputMimeType?: 'image/jpeg' | 'image/png' | 'image/webp';
    readonly imageOutputQuality?: number;
    readonly imageResizeTargetHeight?: number;
    readonly imageResizeTargetWidth?: number;
    readonly imageResizeUpscale?: boolean;
    readonly label?: ReactNode;
    readonly maxFileSize?: number;
    readonly maxFiles?: number;
    readonly multiple?: boolean;
    readonly onFilesChange?: (files: File[], items: DropUploadItem[]) => void;
    readonly onReject?: (rejections: DropUploadRejection[]) => void;
    readonly pasteLabel?: string;
    readonly previewClassName?: string;
    readonly progress?: {
        readonly label?: string;
        readonly value: number;
    };
    readonly ref?: Ref<HTMLDivElement>;
    readonly showPasteButton?: boolean;
    readonly showPreviews?: boolean;
    readonly transformImages?: boolean;
}
declare const DropUploadComponent: ({ accept, browseLabel, className, defaultFiles, disabled: disabledProp, files, helperText, imageOutputMimeType, imageOutputQuality, imageResizeTargetHeight, imageResizeTargetWidth, imageResizeUpscale, label, maxFileSize, maxFiles, multiple, onFilesChange, onPaste, onReject, pasteLabel, previewClassName, ref, progress, showPasteButton, showPreviews, transformImages, ...props }: DropUploadProps) => import("react").JSX.Element;
export declare const DropUpload: import("react").MemoExoticComponent<typeof DropUploadComponent>;
export {};
