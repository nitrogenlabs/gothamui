import type { ReactElement, ReactNode } from 'react';
export declare const SidebarMenuGroup: ({ children, label, onToggle, open }: {
    readonly children: ReactNode;
    readonly label: ReactNode;
    readonly onToggle: () => void;
    readonly open: boolean;
}) => ReactElement;
