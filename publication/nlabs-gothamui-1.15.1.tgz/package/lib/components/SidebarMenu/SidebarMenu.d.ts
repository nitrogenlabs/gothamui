import type { ReactElement, ReactNode } from 'react';
export interface SidebarMenuProps {
    readonly className?: string;
    readonly expandedId: string | null;
    readonly groups: readonly {
        content: ReactNode;
        id: string;
        label: ReactNode;
    }[];
    readonly label?: string;
    readonly onExpandedChange: (id: string | null) => void;
}
export declare const SidebarMenu: ({ className, expandedId, groups, label, onExpandedChange }: SidebarMenuProps) => ReactElement;
