import type { ReactElement, Ref, VideoHTMLAttributes } from 'react';
export interface VideoPlayerProps extends VideoHTMLAttributes<HTMLVideoElement> {
    readonly onPlaybackStop?: (reason: 'ended' | 'error' | 'pause') => void;
    readonly ref?: Ref<HTMLVideoElement>;
}
/** Lightweight single-file playback. No Mediabunny import, decoder pool, or AudioContext per video. */
export declare const VideoPlayer: ({ 'aria-label': label, className, controls, muted: initialMuted, onDurationChange, onEmptied, onEnded, onError, onLoadedMetadata, onPause, onPlay, onPlaybackStop, onSeeked, onTimeUpdate, onVolumeChange, playsInline, poster, preload, ref, src, ...props }: VideoPlayerProps) => ReactElement;
