import type { CanvasPreviewOptions, PreviewScene } from '../../media/canvasPreview.js';
import type { CSSProperties, ReactNode, Ref } from 'react';
export type TimelineVideoScene = PreviewScene;
export interface TimelineVideoPlayerHandle {
    readonly canvas: HTMLCanvasElement | null;
    readonly pause: () => void;
    readonly play: () => Promise<void>;
    readonly seek: (seconds: number) => Promise<void>;
}
export interface TimelineVideoPlayerProps {
    readonly 'aria-label'?: string;
    readonly children?: ReactNode;
    readonly className?: string;
    readonly defaultLoop?: boolean;
    readonly defaultMuted?: boolean;
    readonly defaultRatio?: number;
    /** Caller-owned request policy, e.g. authorization headers for trusted media origins. */
    readonly mediaRequestInit?: CanvasPreviewOptions['mediaRequestInit'];
    readonly onEnded?: () => void;
    readonly onError?: (error: Error) => void;
    readonly onMetadata?: CanvasPreviewOptions['onMetadata'];
    readonly onPlayingChange?: (playing: boolean) => void;
    /** Clock ticks can be forwarded to an ArkhamJS transport without rerendering this player. */
    readonly onPositionChange?: (seconds: number) => void;
    readonly onRatioChange?: (ratio: number) => void;
    readonly onSnapshot?: (canvas: HTMLCanvasElement, seconds: number) => void;
    readonly onStateChange?: CanvasPreviewOptions['onState'];
    readonly options?: ReactNode;
    readonly ref?: Ref<TimelineVideoPlayerHandle>;
    readonly resolveMediaUrl?: CanvasPreviewOptions['resolveMediaUrl'];
    readonly scenes: TimelineVideoScene[];
    readonly style?: CSSProperties;
}
/** Trimmed, overlapping video/image scenes with synchronized audio and shared playback controls. */
export declare const TimelineVideoPlayer: ({ 'aria-label': label, children, className, defaultLoop, defaultMuted, defaultRatio, mediaRequestInit, onEnded, onError, onMetadata, onPlayingChange, onPositionChange, onRatioChange, onSnapshot, onStateChange, options, ref, resolveMediaUrl, scenes, style }: TimelineVideoPlayerProps) => import("react").JSX.Element;
