import type { ComponentPropsWithoutRef } from 'react';
export type HeadingLevel = 1 | 2 | 3 | 4 | 5 | 6;
export type HeadingProps = {
    readonly level?: HeadingLevel;
} & ComponentPropsWithoutRef<'h1'>;
export declare const Heading: ({ className, level, ...props }: HeadingProps) => import("react").JSX.Element;
export declare const Subheading: ({ className, level, ...props }: HeadingProps) => import("react").JSX.Element;
