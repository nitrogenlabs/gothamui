import type { AnchorHTMLAttributes, ComponentType, ReactElement, SVGProps } from 'react';
export type BreadcrumbsVariant = 'contained' | 'chevrons' | 'full';
export interface BreadcrumbItem {
    readonly current?: boolean;
    readonly href?: string;
    readonly label: string;
}
export interface BreadcrumbsProps {
    readonly className?: string;
    readonly homeAriaLabel?: string;
    readonly homeHref?: string;
    readonly homeIcon?: ComponentType<SVGProps<SVGSVGElement>>;
    readonly homeLabel?: string;
    readonly itemClassName?: string;
    readonly items: readonly BreadcrumbItem[];
    readonly linkComponent?: (props: AnchorHTMLAttributes<HTMLAnchorElement>) => ReactElement;
    readonly variant?: BreadcrumbsVariant;
}
export declare const Breadcrumbs: ({ className, homeAriaLabel, homeHref, homeIcon: HomeIcon, homeLabel, itemClassName, items, linkComponent: LinkComponent, variant }: BreadcrumbsProps) => import("react").JSX.Element | null;
