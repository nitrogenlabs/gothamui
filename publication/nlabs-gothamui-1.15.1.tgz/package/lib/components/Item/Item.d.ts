import { SeparatorProps } from '../Separator/Separator.js';
import type { ElementType, HTMLAttributes, ReactNode } from 'react';
export type ItemVariant = 'default' | 'outline' | 'muted';
export type ItemSize = 'default' | 'sm';
export type ItemMediaVariant = 'default' | 'icon' | 'image';
export declare const ItemGroup: ({ className, ...props }: HTMLAttributes<HTMLDivElement>) => import("react").JSX.Element;
export declare const ItemSeparator: ({ className, ...props }: SeparatorProps) => import("react").JSX.Element;
export interface ItemProps extends HTMLAttributes<HTMLElement> {
    readonly as?: ElementType;
    readonly asChild?: boolean;
    readonly children?: ReactNode;
    readonly size?: ItemSize;
    readonly variant?: ItemVariant;
}
export declare const Item: ({ as, asChild, children, className, size, variant, ...props }: ItemProps) => import("react").JSX.Element | null;
export interface ItemMediaProps extends HTMLAttributes<HTMLDivElement> {
    readonly variant?: ItemMediaVariant;
}
export declare const ItemMedia: ({ className, variant, ...props }: ItemMediaProps) => import("react").JSX.Element;
export declare const ItemContent: ({ className, ...props }: HTMLAttributes<HTMLDivElement>) => import("react").JSX.Element;
export declare const ItemTitle: ({ className, ...props }: HTMLAttributes<HTMLDivElement>) => import("react").JSX.Element;
export declare const ItemDescription: ({ className, ...props }: HTMLAttributes<HTMLParagraphElement>) => import("react").JSX.Element;
export declare const ItemActions: ({ className, ...props }: HTMLAttributes<HTMLDivElement>) => import("react").JSX.Element;
export declare const ItemHeader: ({ className, ...props }: HTMLAttributes<HTMLDivElement>) => import("react").JSX.Element;
export declare const ItemFooter: ({ className, ...props }: HTMLAttributes<HTMLDivElement>) => import("react").JSX.Element;
