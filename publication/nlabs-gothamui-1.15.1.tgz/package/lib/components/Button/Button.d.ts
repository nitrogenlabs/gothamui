import type { ButtonHTMLAttributes, ElementType, ReactNode, Ref } from 'react';
import type { GothamColor } from '../../utils/colorUtils.js';
import type { GothamSize } from '../../utils/sizeUtils.js';
export type ButtonType = 'button' | 'reset' | 'submit';
export type ButtonVariant = 'text' | 'solid' | 'outline' | 'contained' | 'outlined';
export interface ButtonProps extends Omit<ButtonHTMLAttributes<HTMLButtonElement>, 'children' | 'color' | 'onClick' | 'type'> {
    readonly as?: ElementType;
    readonly asChild?: boolean;
    readonly backgroundColor?: GothamColor;
    readonly children?: ReactNode;
    readonly color?: GothamColor;
    readonly hasNotification?: boolean;
    readonly hasShadow?: boolean;
    readonly icon?: ReactNode;
    readonly isLoading?: boolean;
    readonly label?: string;
    readonly labelColor?: GothamColor;
    readonly onClick?: (event?: unknown) => void;
    readonly ref?: Ref<HTMLButtonElement>;
    readonly rounded?: number;
    readonly size?: GothamSize;
    readonly type?: ButtonType;
    readonly variant?: ButtonVariant;
}
export declare const Button: ({ as, asChild, backgroundColor, children, className, color, disabled, hasNotification, hasShadow, icon, isLoading, label, labelColor, onClick, ref, rounded, size, style, type, variant, ...props }: ButtonProps) => import("react").JSX.Element | null;
