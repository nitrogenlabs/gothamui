import type { DocumentHeadProps } from '../../head/types.js';
export type { DocumentHeadProps } from '../../head/types.js';
export declare const DocumentHead: ({ cleanup, metadata, missingTags, owner }: DocumentHeadProps) => null;
