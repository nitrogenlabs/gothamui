import type { HTMLAttributes, ReactNode } from 'react';
export type PricingVariant = 'grid' | 'single' | 'comparison';
export type PricingTone = 'default' | 'dark' | 'gradient';
export type PricingCardStyle = 'default' | 'contrast' | 'solid';
export interface PricingFrequency {
    readonly label: string;
    readonly priceSuffix?: string;
    readonly value: string;
}
export interface PricingHighlight {
    readonly description: string;
    readonly disabled?: boolean;
}
export type PricingTierValue = boolean | string;
export interface PricingTier {
    readonly badge?: string;
    readonly ctaLabel?: string;
    readonly ctaSubtitle?: string;
    readonly description?: ReactNode;
    readonly featured?: boolean;
    readonly features?: readonly string[];
    readonly highlights?: readonly PricingHighlight[];
    readonly href?: string;
    readonly id: string;
    readonly name: string;
    readonly price: string | Record<string, string>;
    readonly priceCaption?: ReactNode;
    readonly priceSuffix?: string | Record<string, string>;
}
export interface PricingComparisonFeature {
    readonly name: string;
    readonly tiers: Record<string, PricingTierValue>;
}
export interface PricingComparisonSection {
    readonly features: readonly PricingComparisonFeature[];
    readonly name: string;
}
export interface PricingLogo {
    readonly alt: string;
    readonly className?: string;
    readonly src: string;
}
export interface PricingExtraOffer {
    readonly ctaHref: string;
    readonly ctaLabel: string;
    readonly description?: ReactNode;
    readonly title: ReactNode;
}
export interface PricingSingleOffer {
    readonly ctaHref: string;
    readonly ctaLabel: string;
    readonly description?: ReactNode;
    readonly featureLabel?: ReactNode;
    readonly features?: readonly string[];
    readonly note?: ReactNode;
    readonly price: ReactNode;
    readonly priceLabel?: ReactNode;
    readonly priceSuffix?: ReactNode;
    readonly title: ReactNode;
}
export interface PricingProps extends Omit<HTMLAttributes<HTMLElement>, 'title'> {
    readonly cardStyle?: PricingCardStyle;
    readonly comparisonSections?: readonly PricingComparisonSection[];
    readonly defaultFrequency?: string;
    readonly description?: ReactNode;
    readonly eyebrow?: ReactNode;
    readonly extraOffer?: PricingExtraOffer;
    readonly frequencies?: readonly PricingFrequency[];
    readonly logos?: readonly PricingLogo[];
    readonly singleOffer?: PricingSingleOffer;
    readonly tiers?: readonly PricingTier[];
    readonly title?: ReactNode;
    readonly tone?: PricingTone;
    readonly variant?: PricingVariant;
}
declare const PricingComponent: ({ cardStyle, className, comparisonSections, defaultFrequency, description, eyebrow, extraOffer, frequencies, logos, singleOffer, tiers, title, tone, variant, ...props }: PricingProps) => import("react").JSX.Element;
export declare const Pricing: import("react").MemoExoticComponent<typeof PricingComponent>;
export {};
