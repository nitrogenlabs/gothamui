export type FormErrors = Record<string, {
    readonly message?: string;
    readonly type?: string;
} | string | undefined>;
export type FormValues = Record<string, unknown>;
export interface GothamFormContextValue {
    readonly clearError: (name: string) => void;
    readonly defaultValues: FormValues;
    readonly errors: FormErrors;
    readonly isSubmitting: boolean;
    readonly setValue: (name: string, value: unknown) => void;
    readonly values: FormValues;
}
export declare const GothamFormContext: import("react").Context<GothamFormContextValue | null>;
export declare const useGothamFormContext: () => GothamFormContextValue | null;
export declare const getFormErrorMessage: (error: FormErrors[string]) => string | undefined;
export interface GothamFormFieldValue {
    readonly clearError: GothamFormContextValue['clearError'];
    readonly defaultValue: unknown;
    readonly error: FormErrors[string];
    readonly setValue: GothamFormContextValue['setValue'];
    readonly value: unknown;
}
export declare const createFormFieldStore: (initialValue: GothamFormContextValue) => {
    getSnapshot: () => GothamFormContextValue;
    subscribe: (listener: () => void) => () => void;
    update: (value: GothamFormContextValue) => void;
};
export declare const GothamFormFieldContext: import("react").Context<{
    getSnapshot: () => GothamFormContextValue;
    subscribe: (listener: () => void) => () => void;
    update: (value: GothamFormContextValue) => void;
} | null>;
/** Subscribe only to the named field. Use the full context for cross-field UI. */
export declare const useGothamFormField: (name: string) => GothamFormFieldValue | null;
