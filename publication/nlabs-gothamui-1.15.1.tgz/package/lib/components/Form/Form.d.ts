import { z } from 'zod';
import type { BaseSyntheticEvent, ReactNode } from 'react';
import type { FormErrors, FormValues } from './FormContext.js';
export interface GothamFormMethods {
    readonly formState: {
        readonly errors: FormErrors;
        readonly isSubmitting: boolean;
    };
    readonly getValues: () => FormValues;
    readonly register: (name: string) => {
        readonly defaultValue: unknown;
        readonly name: string;
    };
    readonly setError: (field: string, error: {
        type: string;
        message: string;
    }) => void;
    readonly setValue: (name: string, value: unknown) => void;
}
export interface FormActionState {
    readonly errors: FormErrors;
    readonly values: FormValues;
}
export interface FormProps<T> {
    readonly children: ReactNode | ((methods: GothamFormMethods) => ReactNode);
    readonly className?: string;
    readonly defaultValues?: FormValues;
    readonly disabled?: boolean;
    readonly errors?: FormErrors;
    readonly mode?: 'onSubmit' | 'onBlur' | 'onChange' | 'onTouched' | 'all';
    readonly name?: string;
    readonly onChange?: (data: unknown) => void;
    readonly onSubmit: (data: T, event: BaseSyntheticEvent, setError: (field: string, error: {
        type: string;
        message: string;
    }) => void) => void | Promise<void>;
    readonly schema?: z.ZodSchema<T>;
    readonly showErrors?: boolean;
    readonly validate?: (data: unknown) => void;
    readonly validateOnBlur?: boolean;
}
export declare const Form: <T extends Record<string, unknown>>({ children, className, defaultValues, disabled, errors, name, schema, showErrors, onSubmit }: FormProps<T>) => import("react").JSX.Element;
