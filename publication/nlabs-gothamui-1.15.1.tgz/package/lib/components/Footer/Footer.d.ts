import type { ReactNode } from 'react';
export interface FooterLink {
    readonly href: string;
    readonly label: string;
}
export interface FooterLinkGroup {
    readonly links: readonly FooterLink[];
    readonly title: string;
}
export interface FooterSocialLink extends FooterLink {
    readonly icon?: ReactNode;
}
export interface FooterProps {
    readonly brand?: ReactNode;
    readonly className?: string;
    readonly copyright?: string;
    readonly description?: ReactNode;
    readonly links?: readonly FooterLink[];
    readonly linkGroups?: readonly FooterLinkGroup[];
    readonly socialLinks?: readonly FooterSocialLink[];
    readonly supportEmail?: string;
    readonly supportLabel?: string;
    readonly variant?: 'small' | 'large';
}
export declare const Footer: ({ brand, className, copyright, description, links, linkGroups, socialLinks, supportEmail, supportLabel, variant }: FooterProps) => import("react").JSX.Element;
export default Footer;
