import type { HTMLAttributes } from 'react';
export type AlertVariant = 'default' | 'destructive';
export interface AlertProps extends HTMLAttributes<HTMLDivElement> {
    readonly variant?: AlertVariant;
}
export declare const Alert: ({ className, role, variant, ...props }: AlertProps) => import("react").JSX.Element;
export declare const AlertTitle: ({ className, ...props }: HTMLAttributes<HTMLDivElement>) => import("react").JSX.Element;
export declare const AlertDescription: ({ className, ...props }: HTMLAttributes<HTMLDivElement>) => import("react").JSX.Element;
