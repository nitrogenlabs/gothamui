import type { HTMLAttributes } from 'react';
export interface ListContainerProps extends HTMLAttributes<HTMLUListElement> {
    readonly divided?: boolean;
    readonly inset?: boolean;
    readonly variant?: 'plain' | 'card';
}
export declare const ListContainer: ({ className, divided, inset, variant, ...props }: ListContainerProps) => import("react").JSX.Element;
export declare const ListItem: ({ className, ...props }: HTMLAttributes<HTMLLIElement>) => import("react").JSX.Element;
