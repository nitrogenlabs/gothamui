import type { FC } from 'react';
import type { GothamColor } from '../../utils/colorUtils.js';
export interface LabelProps {
    readonly className?: string;
    readonly color?: GothamColor;
    readonly errorColor?: GothamColor;
    readonly hasError?: boolean;
    readonly label: string;
    readonly name: string;
}
export declare const Label: FC<LabelProps>;
