import type { HTMLAttributes, ReactNode } from 'react';
export interface ReviewItem {
    readonly author: string;
    readonly avatarSrc?: string;
    readonly body: ReactNode;
    readonly id?: string | number;
    readonly rating?: number;
    readonly title?: ReactNode;
}
export interface ReviewListProps extends HTMLAttributes<HTMLDivElement> {
    readonly reviews: ReviewItem[];
}
declare const ReviewListComponent: ({ className, reviews, ...props }: ReviewListProps) => import("react").JSX.Element;
export declare const ReviewList: import("react").MemoExoticComponent<typeof ReviewListComponent>;
export {};
