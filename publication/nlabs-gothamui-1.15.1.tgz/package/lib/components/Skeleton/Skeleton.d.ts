import type { HTMLAttributes } from 'react';
export declare const Skeleton: ({ className, ...props }: HTMLAttributes<HTMLDivElement>) => import("react").JSX.Element;
