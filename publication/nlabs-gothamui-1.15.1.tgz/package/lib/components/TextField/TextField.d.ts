import type { InputHTMLAttributes, Ref } from 'react';
import type { GothamColor } from '../../utils/colorUtils.js';
import type { InputBorderType } from '../InputField/InputField.js';
export interface TextFieldProps extends InputHTMLAttributes<HTMLInputElement | HTMLTextAreaElement> {
    readonly borderColor?: GothamColor;
    readonly borderType?: InputBorderType;
    readonly className?: string;
    readonly color?: GothamColor;
    readonly defaultValue?: string;
    readonly error?: boolean;
    readonly errorColor?: GothamColor;
    readonly hasError?: boolean;
    readonly inputClass?: string;
    readonly label?: string;
    readonly labelClass?: string;
    readonly labelColor?: GothamColor;
    readonly multiline?: boolean;
    readonly name: string;
    readonly onValidate?: (isValid: boolean) => void;
    /** Tab order of the password visibility button; omit to retain normal keyboard access. */
    readonly passwordToggleTabIndex?: number;
    readonly pattern?: string;
    readonly placeholderColor?: GothamColor;
    readonly ref?: Ref<HTMLInputElement | HTMLTextAreaElement>;
    readonly rows?: number;
    readonly showPasswordToggle?: boolean;
    readonly textFillColor?: string;
    readonly textColor?: GothamColor;
    readonly type?: string;
}
declare const TextFieldComponent: ({ borderColor, borderType, className, color, defaultValue, error: externalError, errorColor, inputClass, label, labelClass, labelColor, multiline, name, onChange: onChangeProp, onValidate, passwordToggleTabIndex, pattern, placeholder, placeholderColor, ref, rows, showPasswordToggle, textFillColor, textColor, type, value, ...restInputProps }: TextFieldProps) => import("react").JSX.Element;
export declare const TextField: import("react").MemoExoticComponent<typeof TextFieldComponent>;
export {};
