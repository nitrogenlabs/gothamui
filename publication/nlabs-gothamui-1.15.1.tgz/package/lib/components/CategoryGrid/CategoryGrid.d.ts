import type { HTMLAttributes, ReactNode } from 'react';
export interface CategoryItem {
    readonly description?: ReactNode;
    readonly href?: string;
    readonly id?: string | number;
    readonly imageAlt: string;
    readonly imageSrc: string;
    readonly name: ReactNode;
}
export interface CategoryGridProps extends HTMLAttributes<HTMLDivElement> {
    readonly categories: CategoryItem[];
}
declare const CategoryGridComponent: ({ categories, className, ...props }: CategoryGridProps) => import("react").JSX.Element;
export declare const CategoryGrid: import("react").MemoExoticComponent<typeof CategoryGridComponent>;
export {};
