import type { HTMLAttributes } from 'react';
export type EmptyMediaVariant = 'default' | 'icon';
export declare const Empty: ({ className, ...props }: HTMLAttributes<HTMLDivElement>) => import("react").JSX.Element;
export declare const EmptyHeader: ({ className, ...props }: HTMLAttributes<HTMLDivElement>) => import("react").JSX.Element;
export interface EmptyMediaProps extends HTMLAttributes<HTMLDivElement> {
    readonly variant?: EmptyMediaVariant;
}
export declare const EmptyMedia: ({ className, variant, ...props }: EmptyMediaProps) => import("react").JSX.Element;
export declare const EmptyTitle: ({ className, ...props }: HTMLAttributes<HTMLDivElement>) => import("react").JSX.Element;
export declare const EmptyDescription: ({ className, ...props }: HTMLAttributes<HTMLParagraphElement>) => import("react").JSX.Element;
export declare const EmptyContent: ({ className, ...props }: HTMLAttributes<HTMLDivElement>) => import("react").JSX.Element;
