import type { ReactElement } from 'react';
export interface GothamNotifyAction {
    readonly icon?: string;
    readonly label?: string;
    readonly onClick: (key: string) => void;
}
export type GothamSeverity = 'error' | 'info' | 'success' | 'warning';
export interface GothamNotifyParams {
    readonly actions?: GothamNotifyAction[];
    readonly anchorOrigin?: {
        vertical: 'top' | 'bottom';
        horizontal: 'left' | 'center' | 'right';
    };
    readonly autoHideDuration?: number;
    readonly message?: ReactElement | string;
    readonly severity?: GothamSeverity;
}
export declare const Notify: () => import("react").JSX.Element;
