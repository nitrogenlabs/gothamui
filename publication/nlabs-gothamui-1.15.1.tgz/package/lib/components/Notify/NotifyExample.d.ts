export declare const NotifyExample: () => import("react").JSX.Element;
