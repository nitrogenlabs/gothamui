import type { ChangeEvent } from 'react';
import type { TextFieldProps } from '../TextField/TextField.js';
export type AutocompleteSuggestion = {
    readonly [key: string]: unknown;
    readonly address?: string;
    readonly city?: string;
    readonly country?: string;
    readonly label?: string;
    readonly latitude?: unknown;
    readonly location?: string;
    readonly longitude?: unknown;
    readonly state?: string;
};
export interface AutocompleteFieldProps<TSuggestion = AutocompleteSuggestion> extends Omit<TextFieldProps, 'onChange' | 'value'> {
    readonly [key: string]: unknown;
    readonly defaultValue?: string;
    readonly getList?: (value: string) => Promise<readonly TSuggestion[]>;
    readonly onChange?: (event: ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => void;
    readonly onSelected?: (data: {
        readonly suggestion: TSuggestion;
    }) => void;
    readonly value?: string;
}
export declare const AutocompleteField: <TSuggestion = AutocompleteSuggestion>({ defaultValue, getList, label, name, onChange, onSelected, placeholder, type, value, ...props }: AutocompleteFieldProps<TSuggestion>) => import("react").JSX.Element;
