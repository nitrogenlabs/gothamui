import type { HTMLAttributes, ReactNode } from 'react';
export interface FaqItem {
    readonly answer: ReactNode;
    readonly id?: string;
    readonly question: ReactNode;
}
export interface FaqSectionProps extends Omit<HTMLAttributes<HTMLElement>, 'title'> {
    readonly description?: ReactNode;
    readonly faqs: FaqItem[];
    readonly title: ReactNode;
}
declare const FaqSectionComponent: ({ className, description, faqs, title, ...props }: FaqSectionProps) => import("react").JSX.Element;
export declare const FaqSection: import("react").MemoExoticComponent<typeof FaqSectionComponent>;
export {};
