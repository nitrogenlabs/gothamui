import type { HTMLAttributes } from 'react';
import type { GothamColor } from '../../utils/colorUtils.js';
import type { GothamSize } from '../../utils/sizeUtils.js';
export interface LoaderProps extends HTMLAttributes<HTMLDivElement> {
    readonly color?: GothamColor;
    readonly content?: string;
    readonly size?: GothamSize;
}
export declare const Loader: ({ className, color, content, size, ...props }: LoaderProps) => import("react").JSX.Element;
