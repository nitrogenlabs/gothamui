import type { AnchorHTMLAttributes, ButtonHTMLAttributes, ElementType, FC, HTMLAttributes, ReactNode, Ref } from 'react';
export interface NavbarProps extends HTMLAttributes<HTMLElement> {
    readonly as?: ElementType;
    readonly asChild?: boolean;
    readonly children?: ReactNode;
    readonly isFloating?: boolean;
    readonly isSticky?: boolean;
    readonly mobileMenu?: ReactNode;
    readonly mobileMenuLabel?: string;
    readonly mobileMenuTitle?: ReactNode;
    readonly ref?: Ref<HTMLElement>;
    readonly transparentOnScroll?: boolean;
    readonly transparentScrollBackdropFilter?: string;
    readonly transparentScrollThreshold?: number;
}
export interface NavbarSectionProps extends HTMLAttributes<HTMLDivElement> {
    readonly children?: ReactNode;
    readonly ref?: Ref<HTMLDivElement>;
}
export interface NavbarItemProps extends Omit<ButtonHTMLAttributes<HTMLButtonElement>, 'children' | 'type'> {
    readonly as?: ElementType;
    readonly asChild?: boolean;
    readonly children?: ReactNode;
    readonly current?: boolean;
    readonly href?: AnchorHTMLAttributes<HTMLAnchorElement>['href'];
    readonly ref?: Ref<HTMLElement>;
    readonly type?: ButtonHTMLAttributes<HTMLButtonElement>['type'];
}
export declare const Navbar: FC<NavbarProps>;
export declare const NavbarSection: ({ children, className, ref, ...props }: NavbarSectionProps) => import("react").JSX.Element;
export declare const NavbarItem: ({ as, asChild, children, className, current, href, ref, type, ...props }: NavbarItemProps) => import("react").JSX.Element | null;
export interface NavbarLabelProps extends HTMLAttributes<HTMLSpanElement> {
    readonly ref?: Ref<HTMLSpanElement>;
}
export declare const NavbarLabel: ({ className, ref, ...props }: NavbarLabelProps) => import("react").JSX.Element;
export interface NavbarSpacerProps extends HTMLAttributes<HTMLDivElement> {
    readonly ref?: Ref<HTMLDivElement>;
}
export declare const NavbarSpacer: ({ className, ref, ...props }: NavbarSpacerProps) => import("react").JSX.Element;
export interface NavbarDividerProps extends HTMLAttributes<HTMLDivElement> {
    readonly ref?: Ref<HTMLDivElement>;
}
export declare const NavbarDivider: ({ className, ref, ...props }: NavbarDividerProps) => import("react").JSX.Element;
