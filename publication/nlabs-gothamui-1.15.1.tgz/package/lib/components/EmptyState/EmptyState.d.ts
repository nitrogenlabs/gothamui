import type { ButtonProps } from '../Button/Button.js';
import type { ReactNode } from 'react';
export interface EmptyStateProps {
    readonly action?: ReactNode;
    readonly actionClassName?: string;
    readonly actionIcon?: ReactNode;
    readonly actionLabel?: string;
    readonly actionProps?: Omit<ButtonProps, 'children' | 'icon' | 'label' | 'onClick' | 'variant'>;
    readonly className?: string;
    readonly description: string;
    readonly icon?: ReactNode;
    readonly onAction?: () => void;
    readonly title: string;
}
export declare const EmptyState: ({ action, actionClassName, actionIcon, actionLabel, actionProps, className, description, icon, onAction, title }: EmptyStateProps) => import("react").JSX.Element;
