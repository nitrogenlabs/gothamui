import type { AuthFieldOptions, AuthFormProps, AuthSignInValues } from '../../form/authTypes.js';
export type { AuthSignInValues } from '../../form/authTypes.js';
export interface AuthSignInFormProps extends AuthFormProps<AuthSignInValues> {
    readonly defaultEmail?: string;
    readonly fields?: Partial<Record<'email' | 'password', AuthFieldOptions>>;
    readonly showRememberEmail?: boolean;
}
declare const AuthSignInFormComponent: ({ beforeSubmit, className, defaultEmail, fields, fieldsClassName, name, onSubmit, optionsClassName, optionsContent, pendingLabel, schema, showRememberEmail, showSubmitLoading, submitClassName, submitLabel, submitVariant }: AuthSignInFormProps) => import("react").JSX.Element;
export declare const AuthSignInForm: import("react").MemoExoticComponent<typeof AuthSignInFormComponent>;
