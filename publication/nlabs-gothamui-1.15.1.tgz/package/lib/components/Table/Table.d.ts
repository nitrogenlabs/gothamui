import type { ComponentPropsWithoutRef, FC } from 'react';
export interface TableProps extends ComponentPropsWithoutRef<'div'> {
    readonly bleed?: boolean;
    readonly dense?: boolean;
    readonly grid?: boolean;
    readonly striped?: boolean;
}
export declare const Table: ({ bleed, children, className, dense, grid, striped, ...props }: TableProps) => import("react").JSX.Element;
export declare const TableHead: ({ className, ...props }: ComponentPropsWithoutRef<'thead'>) => import("react").JSX.Element;
export declare const TableBody: (props: ComponentPropsWithoutRef<'tbody'>) => import("react").JSX.Element;
export interface TableRowProps extends ComponentPropsWithoutRef<'tr'> {
    readonly href?: string;
    readonly target?: string;
    readonly title?: string;
}
export declare const TableRow: FC<TableRowProps>;
export declare const TableHeader: FC<ComponentPropsWithoutRef<'th'>>;
export declare const TableCell: FC<ComponentPropsWithoutRef<'td'>>;
