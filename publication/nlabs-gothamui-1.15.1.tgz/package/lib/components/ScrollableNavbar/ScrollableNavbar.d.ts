import type { ReactNode } from 'react';
export type ScrollableNavbarProps = {
    readonly arrowClassName?: string;
    readonly activeKey?: string;
    readonly ariaLabel: string;
    readonly children: ReactNode;
    readonly className?: string;
    readonly wrapperClassName?: string;
};
export declare const ScrollableNavbar: ({ activeKey, ariaLabel, arrowClassName, children, className, wrapperClassName }: ScrollableNavbarProps) => import("react").JSX.Element;
export default ScrollableNavbar;
