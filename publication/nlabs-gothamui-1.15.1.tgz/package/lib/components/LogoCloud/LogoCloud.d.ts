import type { HTMLAttributes } from 'react';
export interface LogoCloudItem {
    readonly alt: string;
    readonly darkSrc?: string;
    readonly height?: number;
    readonly src: string;
    readonly width?: number;
}
export interface LogoCloudProps extends HTMLAttributes<HTMLElement> {
    readonly logos: LogoCloudItem[];
    readonly title?: string;
}
declare const LogoCloudComponent: ({ className, logos, title, ...props }: LogoCloudProps) => import("react").JSX.Element;
export declare const LogoCloud: import("react").MemoExoticComponent<typeof LogoCloudComponent>;
export {};
