import type { InputHTMLAttributes, Ref, TextareaHTMLAttributes } from 'react';
import type { GothamColor } from '../../utils/colorUtils.js';
export type InputBorderType = 'solid' | 'rounded' | 'none' | 'underline';
export interface InputFieldProps extends Omit<InputHTMLAttributes<HTMLInputElement> & TextareaHTMLAttributes<HTMLTextAreaElement>, 'className'> {
    readonly borderColor?: GothamColor;
    readonly borderType?: InputBorderType;
    readonly className?: string;
    readonly id?: string;
    readonly label?: string;
    readonly multiline?: boolean;
    readonly placeholderColor?: GothamColor;
    readonly ref?: Ref<HTMLInputElement | HTMLTextAreaElement>;
    readonly textFillColor?: string;
    readonly textColor?: GothamColor;
}
export declare const baseClasses: {
    none: string;
    rounded: string;
    solid: string;
    underline: string;
};
export declare const getInputBorderClass: (borderType: InputBorderType, borderColor: GothamColor, textColor: GothamColor, placeholderColor: GothamColor) => string;
declare const InputFieldComponent: ({ borderColor, borderType, className, disabled, label, multiline, placeholderColor, ref, style, textFillColor, textColor, ...inputProps }: InputFieldProps) => import("react").JSX.Element;
export declare const InputField: import("react").MemoExoticComponent<typeof InputFieldComponent>;
export {};
