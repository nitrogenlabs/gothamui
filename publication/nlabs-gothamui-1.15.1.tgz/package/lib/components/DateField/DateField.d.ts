import type { InputHTMLAttributes, Ref } from 'react';
import type { GothamColor } from '../../utils/colorUtils.js';
export interface DateFieldProps extends InputHTMLAttributes<HTMLInputElement> {
    readonly className?: string;
    readonly color?: GothamColor;
    readonly defaultValue?: number;
    readonly disabled?: boolean;
    readonly label?: string;
    readonly labelClass?: string;
    readonly labelColor?: GothamColor;
    readonly name: string;
    readonly error?: boolean;
    readonly errorColor?: GothamColor;
    readonly maxDate?: number;
    readonly minDate?: number;
    readonly onChange?: (date: any) => void;
    readonly ref?: Ref<HTMLInputElement>;
    readonly value?: number;
}
declare const DateFieldComponent: ({ className, color, defaultValue, disabled, error: externalError, label, labelClass, labelColor, maxDate, minDate, name, onChange, ref, type, value, ...props }: DateFieldProps) => import("react").JSX.Element;
export declare const DateField: import("react").MemoExoticComponent<typeof DateFieldComponent>;
export {};
