import type { FC } from 'react';
interface DatePickerProps {
    initialDate?: number;
    maxDate?: number;
    minDate?: number;
    onDateSelect?: (date: number) => void;
}
export declare const DatePicker: FC<DatePickerProps>;
export default DatePicker;
