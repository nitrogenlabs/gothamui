import type { HTMLAttributes, ReactNode } from 'react';
export interface ProductItem {
    readonly badge?: ReactNode;
    readonly colors?: string[];
    readonly description?: ReactNode;
    readonly href?: string;
    readonly id?: string | number;
    readonly imageAlt: string;
    readonly imageSrc: string;
    readonly name: ReactNode;
    readonly price?: ReactNode;
}
export interface ProductGridProps extends HTMLAttributes<HTMLDivElement> {
    readonly products: ProductItem[];
}
declare const ProductGridComponent: ({ className, products, ...props }: ProductGridProps) => import("react").JSX.Element;
export interface ProductCardProps extends HTMLAttributes<HTMLElement> {
    readonly product: ProductItem;
}
declare const ProductCardComponent: ({ className, product, ...props }: ProductCardProps) => import("react").JSX.Element;
export declare const ProductGrid: import("react").MemoExoticComponent<typeof ProductGridComponent>;
export declare const ProductCard: import("react").MemoExoticComponent<typeof ProductCardComponent>;
export {};
