import type { HTMLAttributes } from 'react';
export interface SeparatorProps extends HTMLAttributes<HTMLDivElement> {
    readonly decorative?: boolean;
    readonly orientation?: 'horizontal' | 'vertical';
}
export declare const Separator: ({ 'aria-orientation': ariaOrientation, className, decorative, orientation, role, ...props }: SeparatorProps) => import("react").JSX.Element;
