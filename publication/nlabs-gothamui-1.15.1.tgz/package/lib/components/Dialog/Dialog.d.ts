import type { HTMLAttributes, ReactNode, Ref } from 'react';
export type DialogSize = 'xs' | 'sm' | 'md' | 'lg' | 'xl' | '2xl' | '3xl' | '4xl' | '5xl';
export interface DialogProps extends Omit<HTMLAttributes<HTMLDivElement>, 'onClose'> {
    readonly children?: ReactNode;
    readonly open: boolean;
    readonly onClose: (open: boolean) => void;
    readonly size?: DialogSize;
}
export declare const Dialog: ({ children, className, onClose, open, size, ...props }: DialogProps) => import("react").JSX.Element;
export interface DialogTitleProps extends HTMLAttributes<HTMLHeadingElement> {
    readonly ref?: Ref<HTMLHeadingElement>;
}
export declare const DialogTitle: ({ className, ref, ...props }: DialogTitleProps) => import("react").JSX.Element;
export interface DialogDescriptionProps extends HTMLAttributes<HTMLParagraphElement> {
    readonly ref?: Ref<HTMLParagraphElement>;
}
export declare const DialogDescription: ({ className, ref, ...props }: DialogDescriptionProps) => import("react").JSX.Element;
export interface DialogBodyProps extends HTMLAttributes<HTMLDivElement> {
    readonly ref?: Ref<HTMLDivElement>;
}
export declare const DialogBody: ({ className, ref, ...props }: DialogBodyProps) => import("react").JSX.Element;
export interface DialogActionsProps extends HTMLAttributes<HTMLDivElement> {
    readonly ref?: Ref<HTMLDivElement>;
}
export declare const DialogActions: ({ className, ref, ...props }: DialogActionsProps) => import("react").JSX.Element;
