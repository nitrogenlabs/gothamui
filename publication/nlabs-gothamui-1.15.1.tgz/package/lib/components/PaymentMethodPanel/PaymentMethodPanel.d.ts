import type { HTMLAttributes, ReactNode } from 'react';
export interface PaymentMethodPanelProps extends Omit<HTMLAttributes<HTMLElement>, 'title'> {
    readonly actionIcon?: ReactNode;
    readonly addLabel?: string;
    readonly brand?: string;
    readonly description?: ReactNode;
    readonly emptyDescription?: ReactNode;
    readonly emptyTitle?: ReactNode;
    readonly isAdding?: boolean;
    readonly isRemoving?: boolean;
    readonly last4?: string;
    readonly onAdd: () => void;
    readonly onRemove?: () => void;
    readonly removeLabel?: string;
    readonly replaceLabel?: string;
    readonly title?: ReactNode;
}
export declare const PaymentMethodPanel: (paymentMethodPanelProps: PaymentMethodPanelProps) => import("react").JSX.Element;
