import { Field as HeadlessField } from '@headlessui/react';
import type { ComponentPropsWithoutRef, FC, HTMLAttributes, InputHTMLAttributes } from 'react';
import type { GothamColor } from '../../utils/colorUtils.js';
export interface SwitchProps extends Omit<InputHTMLAttributes<HTMLInputElement>, 'type'> {
    readonly color?: GothamColor;
    readonly onCheckedChange?: (checked: boolean) => void;
}
export declare const Switch: FC<SwitchProps>;
export declare const SwitchGroup: ({ className, ...props }: HTMLAttributes<HTMLDivElement>) => import("react").JSX.Element;
export declare const SwitchField: ({ className, ...props }: Omit<ComponentPropsWithoutRef<typeof HeadlessField>, 'as' | 'className'> & {
    readonly className?: string;
}) => import("react").JSX.Element;
