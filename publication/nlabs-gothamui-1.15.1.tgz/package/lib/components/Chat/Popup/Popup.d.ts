import type { FC } from 'react';
import type { IPopupProps } from '../type.js';
export declare const Popup: FC<IPopupProps>;
