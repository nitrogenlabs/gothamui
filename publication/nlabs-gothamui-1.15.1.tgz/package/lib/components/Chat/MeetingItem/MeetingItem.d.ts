import { IMeetingItemProps } from '../type.js';
import type { FC } from 'react';
export declare const MeetingItem: FC<IMeetingItemProps>;
