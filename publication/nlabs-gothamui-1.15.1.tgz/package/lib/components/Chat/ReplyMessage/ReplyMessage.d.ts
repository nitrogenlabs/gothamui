import type { FC } from 'react';
import type { IReplyMessageProps } from '../type.js';
export declare const ReplyMessage: FC<IReplyMessageProps>;
