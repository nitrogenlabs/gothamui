import { IAvatarProps } from '../type.js';
import type { FC } from 'react';
export declare const Avatar: FC<IAvatarProps>;
