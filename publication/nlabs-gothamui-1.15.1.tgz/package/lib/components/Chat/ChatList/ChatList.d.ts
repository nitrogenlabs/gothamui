import type { FC } from 'react';
import type { IChatListProps } from '../type.js';
export declare const ChatList: FC<IChatListProps>;
