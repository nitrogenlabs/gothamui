import type { FC } from 'react';
import type { ISpotifyMessageProps } from '../type.js';
export declare const SpotifyMessage: FC<ISpotifyMessageProps>;
