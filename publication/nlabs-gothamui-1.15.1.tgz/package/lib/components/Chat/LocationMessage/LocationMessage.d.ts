import { ILocationMessageProps } from '../type.js';
import type { FC } from 'react';
export declare const LocationMessage: FC<ILocationMessageProps>;
