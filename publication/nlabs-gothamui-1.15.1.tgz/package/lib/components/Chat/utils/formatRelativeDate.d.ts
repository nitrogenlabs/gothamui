export type DateInput = Date | string | number;
export declare const resolveDateValue: (added?: DateInput, date?: DateInput) => DateInput | undefined;
export declare const formatRelativeDate: (value: DateInput) => string;
export declare const useRelativeDateText: (value?: DateInput, dateString?: string) => string;
