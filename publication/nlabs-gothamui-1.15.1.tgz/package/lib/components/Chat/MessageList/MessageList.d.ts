import type { IMessageListProps } from '../type.js';
export declare const MessageList: import("react").NamedExoticComponent<IMessageListProps>;
