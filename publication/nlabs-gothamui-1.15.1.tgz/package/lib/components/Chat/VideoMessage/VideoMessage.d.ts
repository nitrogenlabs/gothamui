import type { FC } from 'react';
import type { IVideoMessageProps } from '../type.js';
export declare const VideoMessage: FC<IVideoMessageProps>;
