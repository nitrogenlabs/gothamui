import { IChatItemProps } from '../type.js';
import type { FC } from 'react';
export declare const ChatItem: FC<IChatItemProps>;
