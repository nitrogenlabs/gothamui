import type { FC } from 'react';
import type { MessageBoxType } from '../type.js';
export declare const MessageBox: FC<MessageBoxType>;
