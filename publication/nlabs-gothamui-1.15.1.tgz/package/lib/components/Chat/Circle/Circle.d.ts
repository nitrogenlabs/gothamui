import type { FC } from 'react';
import type { ICircleProps } from '../type.js';
export declare const ProgressCircle: FC<ICircleProps>;
