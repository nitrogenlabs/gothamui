import type { FC } from 'react';
import type { IMeetingMessageProps } from '../type.js';
export declare const MeetingMessage: FC<IMeetingMessageProps>;
