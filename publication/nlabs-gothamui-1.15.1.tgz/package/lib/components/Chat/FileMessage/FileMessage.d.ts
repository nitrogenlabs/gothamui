import type { FC } from 'react';
import type { IFileMessageProps } from '../type.js';
export declare const FileMessage: FC<IFileMessageProps>;
