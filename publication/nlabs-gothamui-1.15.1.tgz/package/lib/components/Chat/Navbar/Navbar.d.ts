import { INavbarProps } from '../type.js';
import type { FC } from 'react';
export declare const Navbar: FC<INavbarProps>;
