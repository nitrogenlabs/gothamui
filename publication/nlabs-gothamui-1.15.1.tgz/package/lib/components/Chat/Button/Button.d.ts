import { IButtonProps } from '../type.js';
import type { FC } from 'react';
export declare const Button: FC<IButtonProps>;
