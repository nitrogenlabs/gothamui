import type { FC } from 'react';
import type { IInputProps } from '../type.js';
export declare const Input: FC<IInputProps>;
