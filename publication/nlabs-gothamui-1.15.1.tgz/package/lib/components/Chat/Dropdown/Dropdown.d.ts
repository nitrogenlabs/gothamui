import type { FC } from 'react';
import type { IDropdownProps } from '../type.js';
export declare const Dropdown: FC<IDropdownProps>;
