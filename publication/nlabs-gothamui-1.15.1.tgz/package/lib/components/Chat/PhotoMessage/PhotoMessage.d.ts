import type { FC } from 'react';
import type { IPhotoMessageProps } from '../type.js';
export declare const PhotoMessage: FC<IPhotoMessageProps>;
