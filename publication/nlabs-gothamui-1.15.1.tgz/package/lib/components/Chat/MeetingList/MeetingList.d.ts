import type { FC } from 'react';
import type { IMeetingListProps } from '../type.js';
export declare const MeetingList: FC<IMeetingListProps>;
