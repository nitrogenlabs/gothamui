import type { FC } from 'react';
import type { ISideBarProps } from '../type.js';
export declare const SideBar: FC<ISideBarProps>;
