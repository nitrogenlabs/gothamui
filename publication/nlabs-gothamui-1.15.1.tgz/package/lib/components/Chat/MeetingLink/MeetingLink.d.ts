import type { FC } from 'react';
import type { IMeetingLinkMessageProps } from '../type.js';
export declare const MeetingLink: FC<IMeetingLinkMessageProps>;
