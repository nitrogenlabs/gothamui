import type { FC } from 'react';
import type { ISystemMessageProps } from '../type.js';
export declare const SystemMessage: FC<ISystemMessageProps>;
