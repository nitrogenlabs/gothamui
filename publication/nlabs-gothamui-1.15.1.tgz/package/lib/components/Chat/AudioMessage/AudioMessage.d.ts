import { IAudioMessageProps } from '../type.js';
import type { FC } from 'react';
export declare const AudioMessage: FC<IAudioMessageProps>;
