import type { HTMLAttributes } from 'react';
export type PasswordStrength = {
    readonly label: string;
    readonly score: number;
};
export interface PasswordStrengthMeterProps extends HTMLAttributes<HTMLDivElement> {
    readonly password: string;
}
export declare const getPasswordStrength: (password: string) => PasswordStrength;
declare const PasswordStrengthMeterComponent: ({ className, password, ...props }: PasswordStrengthMeterProps) => import("react").JSX.Element | null;
export declare const PasswordStrengthMeter: import("react").MemoExoticComponent<typeof PasswordStrengthMeterComponent>;
export {};
