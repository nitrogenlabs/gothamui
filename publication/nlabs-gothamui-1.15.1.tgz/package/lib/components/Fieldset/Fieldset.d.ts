import { Description as HeadlessDescription, Field as HeadlessField, Fieldset as HeadlessFieldset, Label as HeadlessLabel, Legend as HeadlessLegend } from '@headlessui/react';
import type { ComponentPropsWithoutRef } from 'react';
export declare const Fieldset: ({ className, ...props }: Omit<ComponentPropsWithoutRef<typeof HeadlessFieldset>, 'as' | 'className'> & {
    readonly className?: string;
}) => import("react").JSX.Element;
export declare const Legend: ({ className, ...props }: Omit<ComponentPropsWithoutRef<typeof HeadlessLegend>, 'as' | 'className'> & {
    readonly className?: string;
}) => import("react").JSX.Element;
export declare const FieldGroup: ({ className, ...props }: ComponentPropsWithoutRef<'div'>) => import("react").JSX.Element;
export declare const Field: ({ className, ...props }: Omit<ComponentPropsWithoutRef<typeof HeadlessField>, 'as' | 'className'> & {
    readonly className?: string;
}) => import("react").JSX.Element;
export declare const FieldLabel: ({ className, ...props }: Omit<ComponentPropsWithoutRef<typeof HeadlessLabel>, 'as' | 'className'> & {
    readonly className?: string;
}) => import("react").JSX.Element;
export declare const FieldDescription: ({ className, ...props }: Omit<ComponentPropsWithoutRef<typeof HeadlessDescription>, 'as' | 'className'> & {
    readonly className?: string;
}) => import("react").JSX.Element;
export declare const FieldError: ({ className, ...props }: Omit<ComponentPropsWithoutRef<typeof HeadlessDescription>, 'as' | 'className'> & {
    readonly className?: string;
}) => import("react").JSX.Element;
