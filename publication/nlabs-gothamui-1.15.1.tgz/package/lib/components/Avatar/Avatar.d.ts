import type { ButtonHTMLAttributes, HTMLAttributes, ImgHTMLAttributes, ReactNode, SyntheticEvent } from 'react';
export type AvatarSize = 'default' | 'sm' | 'lg';
type AvatarImageEventHandler = (event: SyntheticEvent<HTMLImageElement>) => void;
export interface AvatarProps extends Omit<HTMLAttributes<HTMLDivElement>, 'onError' | 'onLoad'> {
    readonly alt?: string;
    readonly initials?: ReactNode;
    readonly onError?: AvatarImageEventHandler;
    readonly onLoad?: AvatarImageEventHandler;
    readonly size?: AvatarSize;
    readonly square?: boolean;
    readonly src?: string;
}
export declare const Avatar: ({ alt, children, className, initials, onError, onLoad, size, square, src, ...props }: AvatarProps) => import("react").JSX.Element;
export declare const AvatarImage: ({ alt, className, onError, onLoad, ...props }: ImgHTMLAttributes<HTMLImageElement>) => import("react").JSX.Element;
export declare const AvatarFallback: ({ children, className, ...props }: HTMLAttributes<HTMLDivElement>) => import("react").JSX.Element | null;
export declare const AvatarBadge: ({ className, ...props }: HTMLAttributes<HTMLSpanElement>) => import("react").JSX.Element;
export interface AvatarButtonProps extends Omit<ButtonHTMLAttributes<HTMLButtonElement>, 'onError' | 'onLoad'> {
    readonly alt?: string;
    readonly initials?: ReactNode;
    readonly onError?: AvatarImageEventHandler;
    readonly onLoad?: AvatarImageEventHandler;
    readonly size?: AvatarSize;
    readonly square?: boolean;
    readonly src?: string;
}
export declare const AvatarButton: ({ alt, children, className, initials, onError, onLoad, size, square, src, type, ...props }: AvatarButtonProps) => import("react").JSX.Element;
export declare const AvatarGroup: ({ className, ...props }: HTMLAttributes<HTMLDivElement>) => import("react").JSX.Element;
export declare const AvatarGroupCount: ({ children, className, ...props }: HTMLAttributes<HTMLDivElement>) => import("react").JSX.Element;
export {};
