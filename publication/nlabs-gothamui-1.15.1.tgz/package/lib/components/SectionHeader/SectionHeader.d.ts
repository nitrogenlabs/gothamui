import type { HTMLAttributes, ReactNode } from 'react';
export interface SectionHeaderProps extends Omit<HTMLAttributes<HTMLDivElement>, 'title'> {
    readonly actions?: ReactNode;
    readonly align?: 'left' | 'center';
    readonly eyebrow?: ReactNode;
    readonly subtitle?: ReactNode;
    readonly title: ReactNode;
}
export declare const SectionHeader: ({ actions, align, children, className, eyebrow, subtitle, title, ...props }: SectionHeaderProps) => import("react").JSX.Element;
