import type { InputHTMLAttributes } from 'react';
export interface CheckboxProps extends Omit<InputHTMLAttributes<HTMLInputElement>, 'type' | 'className' | 'defaultValue'> {
    color?: 'primary' | 'secondary' | 'error' | 'success' | 'warning';
    containerClass?: string;
    defaultValue?: boolean;
    description?: string;
    error?: string;
    label: string;
    labelClass?: string;
    name: string;
    optionClass?: string;
}
declare const CheckboxComponent: ({ color, label, defaultValue, description, error, containerClass, labelClass, name, optionClass, id, ...props }: CheckboxProps) => import("react").JSX.Element;
export declare const Checkbox: import("react").MemoExoticComponent<typeof CheckboxComponent>;
export {};
