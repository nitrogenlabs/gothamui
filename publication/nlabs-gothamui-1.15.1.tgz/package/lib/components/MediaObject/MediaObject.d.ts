import type { HTMLAttributes, ReactNode } from 'react';
export interface MediaObjectProps extends Omit<HTMLAttributes<HTMLDivElement>, 'title'> {
    readonly align?: 'start' | 'center' | 'end' | 'stretch';
    readonly description?: ReactNode;
    readonly media: ReactNode;
    readonly title?: ReactNode;
}
export declare const MediaObject: ({ align, children, className, description, media, title, ...props }: MediaObjectProps) => import("react").JSX.Element;
