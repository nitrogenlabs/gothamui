import type { HTMLAttributes, ReactElement, ReactNode } from 'react';
export interface DrawerProps extends Omit<HTMLAttributes<HTMLDivElement>, 'onClose'> {
    readonly backdropClassName?: string;
    readonly children?: ReactNode;
    readonly onAfterClose?: () => void;
    readonly onClose: (open: boolean) => void;
    readonly open: boolean;
    readonly side?: 'left' | 'right';
}
/** Accessible modal drawer with a damped spring and retained presence during exit. */
export declare const Drawer: ({ backdropClassName, children, className, onAfterClose, onClose, open, side, style, ...props }: DrawerProps) => ReactElement;
