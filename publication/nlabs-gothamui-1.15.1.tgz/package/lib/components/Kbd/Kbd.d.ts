import type { HTMLAttributes } from 'react';
export declare const Kbd: ({ className, ...props }: HTMLAttributes<HTMLElement>) => import("react").JSX.Element;
