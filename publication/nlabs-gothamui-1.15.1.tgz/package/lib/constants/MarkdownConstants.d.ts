/**
 * Copyright (c) 2018-Present, Nitrogen Labs, Inc.
 * Copyrights licensed under the MIT License. See the accompanying LICENSE file for terms.
 */
export declare class MarkdownConstants {
    static readonly CLEAR_EXTERNAL: string;
    static readonly GET_EXTERNAL: string;
}
