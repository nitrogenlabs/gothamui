/**
 * Copyright (c) 2018-Present, Nitrogen Labs, Inc.
 * Copyrights licensed under the MIT License. See the accompanying LICENSE file for terms.
 */
export declare class GothamConstants {
    static readonly ALERT: string;
    static readonly CLEAR_EXTERNAL: string;
    static readonly GET_EXTERNAL: string;
    static readonly INITIALIZE: string;
    static readonly LOADING: string;
    static readonly NAV_BACK: string;
    static readonly NAV_FORWARD: string;
    static readonly NAV_GOTO: string;
    static readonly NAV_REPLACE: string;
    static readonly NOTIFY_OPEN: string;
    static readonly NOTIFY_CLOSE: string;
    static readonly SET_CONFIG: string;
    static readonly SIGN_OUT: string;
    static readonly TOGGLE_MENU: string;
    static readonly TOP_BAR_SOLID: string;
    static readonly UPDATE_MENU: string;
    static readonly UPDATE_SESSION: string;
    static readonly UPDATE_TITLE: string;
}
