/**
 * Copyright (c) 2019-Present, Nitrogen Labs, Inc.
 * Copyrights licensed under the MIT License. See the accompanying LICENSE file for terms.
 */
export declare class MessageConstants {
    static readonly CONVO_LIST_FAILED: string;
    static readonly CONVO_LIST_SUCCESS: string;
    static readonly GET_LIST_FAILED: string;
    static readonly GET_LIST_SUCCESS: string;
}
