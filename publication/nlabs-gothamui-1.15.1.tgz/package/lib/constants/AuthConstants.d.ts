/**
 * Copyright (c) 2018-Present, Nitrogen Labs, Inc.
 * Copyrights licensed under the MIT License. See the accompanying LICENSE file for terms.
 */
export declare class AuthConstants {
    static readonly SIGN_IN_SUCCESS: string;
    static readonly SIGN_IN_FAILED: string;
}
