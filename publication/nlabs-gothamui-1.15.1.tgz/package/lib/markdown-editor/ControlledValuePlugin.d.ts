import type { FC, RefObject } from 'react';
export declare const CONTROLLED_VALUE_TAG = "gothamui-controlled-value";
export declare const stripUnsupportedCaseFormats: () => void;
export interface ControlledValuePluginProps {
    readonly lastMarkdownRef: RefObject<string>;
    readonly value: string;
}
export declare const ControlledValuePlugin: FC<ControlledValuePluginProps>;
