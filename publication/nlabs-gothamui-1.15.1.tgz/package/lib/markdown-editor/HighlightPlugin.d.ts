import type { FC } from 'react';
import type { MarkdownEditorHighlight } from './markdownEditorTypes.js';
export declare const HIGHLIGHT_NAME = "gothamui-markdown-highlight";
export interface HighlightAnchor {
    bottom: number;
    highlightId: string;
    left: number;
    right: number;
    top: number;
}
export interface HighlightPluginProps {
    readonly highlights: MarkdownEditorHighlight[];
    readonly onAnchorsChange: (anchors: HighlightAnchor[]) => void;
    readonly value: string;
}
export declare const HighlightPlugin: FC<HighlightPluginProps>;
