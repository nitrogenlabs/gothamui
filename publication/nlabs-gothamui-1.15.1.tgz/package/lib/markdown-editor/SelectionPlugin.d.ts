import type { FC } from 'react';
import type { MarkdownEditorSelection } from './markdownEditorTypes.js';
export interface SelectionPluginProps {
    readonly onSelectionChange?: (selection: MarkdownEditorSelection | null) => void;
}
export declare const SelectionPlugin: FC<SelectionPluginProps>;
