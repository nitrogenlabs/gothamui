import type { FC } from 'react';
import type { MarkdownEditorProps } from './markdownEditorTypes.js';
export declare const MarkdownEditor: FC<MarkdownEditorProps>;
