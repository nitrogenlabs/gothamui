import type { FC } from 'react';
export interface MarkdownEditorToolbarProps {
    readonly onRequestLink?: () => null | string | Promise<null | string>;
}
export declare const MarkdownEditorToolbar: FC<MarkdownEditorToolbarProps>;
