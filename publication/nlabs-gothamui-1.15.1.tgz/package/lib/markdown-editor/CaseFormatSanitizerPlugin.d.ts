import type { FC } from 'react';
export declare const CaseFormatSanitizerPlugin: FC;
