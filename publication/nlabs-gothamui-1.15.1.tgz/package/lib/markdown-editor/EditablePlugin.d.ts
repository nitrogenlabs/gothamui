import type { FC } from 'react';
export interface EditablePluginProps {
    readonly editable: boolean;
}
export declare const EditablePlugin: FC<EditablePluginProps>;
