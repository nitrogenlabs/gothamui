export declare const OptimizedFormExample: () => import("react").JSX.Element;
