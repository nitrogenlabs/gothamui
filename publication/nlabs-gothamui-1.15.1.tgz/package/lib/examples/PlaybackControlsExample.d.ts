import * as React from 'react';
/** Connect the presentation-only controls to a native video element. */
export declare const PlaybackControlsExample: ({ src }: {
    readonly src: string;
}) => React.JSX.Element;
