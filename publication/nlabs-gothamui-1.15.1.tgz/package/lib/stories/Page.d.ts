import './page.css';
import type { FC } from 'react';
export declare const Page: FC;
