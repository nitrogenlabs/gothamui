/**
 * Copyright (c) 2018-Present, Nitrogen Labs, Inc.
 * Copyrights licensed under the MIT License. See the accompanying LICENSE file for terms.
 */
import { Flux } from '@nlabs/arkhamjs';
import { GothamConfiguration } from '../views/Gotham/GothamProvider.js';
import type { ReactElement } from 'react';
export interface GothamNotifyAction {
    readonly icon?: string;
    readonly label?: string;
    readonly onClick: (key: string) => void;
}
export type GothamSeverity = 'error' | 'info' | 'success' | 'warning';
export interface GothamNotifyParams {
    readonly actions?: GothamNotifyAction[];
    readonly anchorOrigin?: {
        horizontal: 'left' | 'center' | 'right';
        vertical: 'top' | 'bottom';
    };
    readonly autoHideDuration?: number;
    readonly key?: string;
    readonly message?: ReactElement | string;
    readonly severity?: GothamSeverity;
}
export interface NavParams {
    path: string;
    state?: Record<string, unknown>;
}
export declare const GothamActions: {
    readonly getState: (...args: Parameters<typeof Flux.getState>) => unknown;
    readonly init: () => Promise<import("@nlabs/arkhamjs").FluxAction>;
    readonly loading: (isLoading: boolean, content?: string) => Promise<import("@nlabs/arkhamjs").FluxAction>;
    readonly navBack: () => Promise<import("@nlabs/arkhamjs").FluxAction>;
    readonly navForward: () => Promise<import("@nlabs/arkhamjs").FluxAction>;
    readonly navGoto: (path: string, params?: Record<string, unknown>) => Promise<import("@nlabs/arkhamjs").FluxAction>;
    readonly navReplace: (path: string, params?: Record<string, unknown>) => Promise<import("@nlabs/arkhamjs").FluxAction>;
    readonly notify: (params: GothamNotifyParams) => Promise<import("@nlabs/arkhamjs").FluxAction>;
    readonly notifyClose: () => Promise<import("@nlabs/arkhamjs").FluxAction>;
    readonly setConfig: (config: GothamConfiguration) => Promise<import("@nlabs/arkhamjs").FluxAction>;
    readonly signOut: () => Promise<import("@nlabs/arkhamjs").FluxAction>;
    readonly updateTitle: (title: string, separator?: string) => Promise<import("@nlabs/arkhamjs").FluxAction>;
};
