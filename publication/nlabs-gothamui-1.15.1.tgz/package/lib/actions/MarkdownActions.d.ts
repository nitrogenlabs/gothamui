export declare class MarkdownActions {
    static clearExternal(): Promise<import("@nlabs/arkhamjs").FluxAction>;
    static getExternal(url: string): Promise<import("@nlabs/arkhamjs").FluxAction>;
}
