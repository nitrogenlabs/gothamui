import type { RouteProps } from 'react-router';
export interface GothamRouteAnalytics {
    readonly route?: string;
    readonly title?: string;
    readonly viewId: string;
}
export type GothamRouteAnalyticsSource = GothamRouteAnalytics | ((pathname: string) => GothamRouteAnalytics | undefined);
export type GothamRouteData = Omit<RouteProps, 'children'> & {
    readonly analytics?: GothamRouteAnalyticsSource;
    readonly authenticate?: boolean;
    readonly props?: any;
    readonly children?: GothamRouteData[];
    readonly index?: boolean;
};
