import { z } from 'zod';
export declare const authSignInSchema: z.ZodObject<{
    email: z.ZodEmail;
    password: z.ZodString;
    rememberEmail: z.ZodBoolean;
}, z.core.$strip>;
export declare const authSignUpSchema: z.ZodObject<{
    acceptTerms: z.ZodBoolean;
    confirmPassword: z.ZodString;
    email: z.ZodEmail;
    password: z.ZodString;
}, z.core.$strip>;
